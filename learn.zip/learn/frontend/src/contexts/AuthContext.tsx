import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { authApi } from '../services/api'

interface User {
  id: number
  name: string
  email: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string, otp?: string) => Promise<{ success: boolean; requiresOtp?: boolean; message?: string }>
  register: (name: string, email: string, password: string) => Promise<boolean>
  logout: () => void
  isAuthenticated: boolean
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem('user')
    const storedToken = localStorage.getItem('token')
    if (storedUser && storedToken) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        console.error('Error parsing stored user:', error)
        localStorage.removeItem('user')
        localStorage.removeItem('token')
      }
    }
    setLoading(false)
  }, [])

  const login = async (email: string, password: string, otp?: string): Promise<{ success: boolean; requiresOtp?: boolean; message?: string }> => {
    try {
      const response = await authApi.login(email, password, otp)
      
      // If OTP is required
      if (response.requiresOtp) {
        return {
          success: false,
          requiresOtp: true,
          message: response.message || 'OTP required'
        }
      }

      // Login successful
      if (response.access_token && response.user) {
        const userData: User = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email
        }
        setUser(userData)
        localStorage.setItem('user', JSON.stringify(userData))
        localStorage.setItem('token', response.access_token)
        return { success: true }
      }

      return { success: false, message: 'Invalid response from server' }
    } catch (error: any) {
      const message = error.response?.data?.message || error.message || 'Login failed'
      return { success: false, message }
    }
  }

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      const response = await authApi.register(name, email, password)
      if (response.access_token && response.user) {
        const userData: User = {
          id: response.user.id,
          name: response.user.name,
          email: response.user.email
        }
        setUser(userData)
        localStorage.setItem('user', JSON.stringify(userData))
        localStorage.setItem('token', response.access_token)
        return true
      }
      return false
    } catch (error: any) {
      console.error('Registration error:', error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('user')
    localStorage.removeItem('token')
  }

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    isAuthenticated: !!user,
    loading
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}



