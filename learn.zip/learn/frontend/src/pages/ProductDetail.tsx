import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingBag, Heart, Star, Check, Minus, Plus } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('9');
  const [selectedColor, setSelectedColor] = useState('Black');

  // Mock product data
  const product = {
    id: parseInt(id || '1'),
    name: 'Stride Velocity X',
    description: 'Engineered with AeroFoam™ technology for maximum energy return. Lightweight design with responsive cushioning and breathable mesh upper. Perfect for long-distance running and daily training.',
    price: 179.99,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1000&auto=format&fit=crop',
    features: [
      'AeroFoam™ midsole technology',
      'Lightweight mesh upper',
      'Responsive cushioning system',
      'Durable rubber outsole',
      'Reflective safety details'
    ],
    sizes: ['7', '8', '9', '10', '11', '12'],
    colors: ['Black', 'White', 'Navy', 'Gray']
  };

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart({
        id: product.id,
        name: product.name,
        description: product.description,
        price: product.price,
        emoji: '👟'
      });
    }
    navigate('/cart');
  };

  return (
    <div className="pt-24 pb-20 min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-600 hover:text-indigo-600 transition-colors mb-8 font-medium"
          >
            <ArrowLeft size={20} /> Back
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Image */}
            <div className="relative">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 sticky top-24">
                <div className="aspect-square bg-gray-50 flex items-center justify-center p-8">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-contain transform rotate-[-15deg] hover:rotate-[-5deg] transition-transform duration-500"
                  />
                </div>
              </div>
            </div>

            {/* Info */}
            <div className="space-y-6">
              <div>
                <h1 className="text-4xl md:text-5xl font-black text-gray-900 mb-4 leading-tight">
                  {product.name}
                </h1>
                <div className="flex items-center gap-2 mb-4">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} size={18} className="text-yellow-400 fill-current" />
                  ))}
                  <span className="text-sm text-gray-500 ml-2">(142 reviews)</span>
                </div>
                <div className="text-4xl font-black text-indigo-600 mb-6">
                  ${product.price.toFixed(2)}
                </div>
              </div>

              <p className="text-gray-600 text-lg leading-relaxed">{product.description}</p>

              {/* Features */}
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Features</h3>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-3 text-gray-700">
                      <div className="w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check size={12} className="text-indigo-600" />
                      </div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Options */}
              <div className="space-y-4 border-t border-gray-200 pt-6">
                {/* Size */}
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                    Size
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-6 py-3 rounded-lg font-bold transition-all ${
                          selectedSize === size
                            ? 'bg-indigo-600 text-white shadow-lg'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color */}
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                    Color
                  </label>
                  <div className="flex gap-3">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        onClick={() => setSelectedColor(color)}
                        className={`px-6 py-3 rounded-lg font-bold border-2 transition-all ${
                          selectedColor === color
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-600'
                            : 'border-gray-200 text-gray-700 hover:border-gray-300'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quantity */}
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                    Quantity
                  </label>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-3 bg-gray-100 rounded-lg p-1">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-10 h-10 rounded-lg bg-white hover:bg-indigo-600 hover:text-white transition-colors flex items-center justify-center"
                      >
                        <Minus size={18} />
                      </button>
                      <span className="w-12 text-center font-bold text-gray-900 text-lg">{quantity}</span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-10 h-10 rounded-lg bg-white hover:bg-indigo-600 hover:text-white transition-colors flex items-center justify-center"
                      >
                        <Plus size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-4">
                <button
                  onClick={handleAddToCart}
                  className="flex-1 px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2"
                >
                  <ShoppingBag size={20} /> Add to Cart
                </button>
                <button
                  onClick={handleAddToCart}
                  className="px-8 py-4 bg-gray-900 hover:bg-gray-800 text-white rounded-lg font-bold text-lg transition-all flex items-center justify-center"
                >
                  Buy Now
                </button>
                <button className="p-4 border-2 border-gray-200 hover:border-gray-300 rounded-lg transition-colors">
                  <Heart size={20} className="text-gray-600" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
};

export default ProductDetail;