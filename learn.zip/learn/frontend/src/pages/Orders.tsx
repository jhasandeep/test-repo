import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Package, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Orders: React.FC = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  if (!isAuthenticated) {
    return (
      <div className="pt-24 pb-20 min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900 relative overflow-hidden">
          <div className="max-w-md w-full mx-auto px-4 text-center">
            <div className="bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl p-8 border border-gray-100">
              <h2 className="text-2xl font-black text-gray-900 mb-4">Please log in</h2>
              <p className="text-gray-600 mb-8">You need to be logged in to view your orders.</p>
              <button
                onClick={() => navigate('/login')}
                className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg shadow-indigo-600/30"
              >
                Go to Login
              </button>
            </div>
          </div>
        </div>
    );
  }

  // Mock orders data
  const orders = [
    {
      id: '12345',
      date: 'January 15, 2024',
      status: 'Delivered',
      items: [
        { name: 'Premium Runner', quantity: 2, price: 129.99 }
      ],
      total: 285.98
    },
    {
      id: '12346',
      date: 'January 10, 2024',
      status: 'Shipped',
      items: [
        { name: 'Elite Trainer', quantity: 1, price: 149.99 }
      ],
      total: 164.99
    }
  ];

  return (
    <div className="pt-24 pb-20 min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-center justify-between mb-12">
            <h2 className="text-4xl font-black text-gray-900">Order History</h2>
            <Link
              to="/"
              className="flex items-center gap-2 text-indigo-600 font-bold hover:text-indigo-800 transition-colors"
            >
              Continue Shopping <ArrowRight size={18} />
            </Link>
          </div>

          {orders.length === 0 ? (
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-12 text-center">
              <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Package className="w-10 h-10 text-indigo-600" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-3">No orders yet</h3>
              <p className="text-gray-600 mb-8">Start shopping to see your orders here!</p>
              <Link
                to="/"
                className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg shadow-indigo-600/30 inline-block"
              >
                Continue Shopping
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 hover:shadow-xl transition-all duration-300"
                >
                  <div className="flex justify-between items-start mb-6 pb-6 border-b border-gray-200">
                    <div>
                      <h3 className="text-2xl font-black text-gray-900 mb-2">Order #{order.id}</h3>
                      <p className="text-gray-600">Ordered on {order.date}</p>
                    </div>
                    <span
                      className={`px-4 py-2 rounded-lg font-bold text-sm ${
                        order.status === 'Delivered'
                          ? 'bg-green-100 text-green-700'
                          : order.status === 'Shipped'
                          ? 'bg-indigo-100 text-indigo-700'
                          : 'bg-yellow-100 text-yellow-700'
                      }`}
                    >
                      {order.status}
                    </span>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    {order.items.map((item, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center text-gray-700"
                      >
                        <span>{item.name} x {item.quantity}</span>
                        <span className="font-bold">${(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                    <div className="text-2xl font-black text-gray-900">
                      Total: ${order.total.toFixed(2)}
                    </div>
                    <button className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold transition-all flex items-center gap-2">
                      View Details <ArrowRight size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
  );
};

export default Orders;