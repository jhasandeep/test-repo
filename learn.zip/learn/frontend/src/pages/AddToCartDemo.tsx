import React from 'react';
import { useCart } from '../contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import AddToCart from '../components/AddToCart';

const AddToCartDemo: React.FC = () => {
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const productPrice = 179.99;
  const productName = 'Stride Velocity X';

  const handleAddToCart = (quantity: number) => {
    // Add product to cart with the selected quantity
    for (let i = 0; i < quantity; i++) {
      addToCart({
        id: 999,
        name: productName,
        description: 'High-performance running shoe with AeroFoam technology',
        price: productPrice,
        emoji: '👟'
      });
    }
    
    // Show success message
    alert(`Added ${quantity} ${productName}${quantity > 1 ? 's' : ''} to cart!`);
    
    // Optional: Navigate to cart after adding
    // navigate('/cart');
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center py-20 px-4 relative overflow-hidden">
      {/* Background decorations matching hero section */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-indigo-600/20 blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-rose-500/20 blur-[100px] animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-black text-white mb-2">
            Add to Cart Component
          </h1>
          <p className="text-gray-400 text-sm">
            Modern glass panel design with gradient button
          </p>
        </div>
        <AddToCart
          price={productPrice}
          onAddToCart={handleAddToCart}
          productName={productName}
        />
      </div>
    </div>
  );
};

export default AddToCartDemo;