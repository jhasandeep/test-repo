import React from 'react';
import {
  Users,
  ShoppingCart,
  Building2,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Activity,
  FileText,
  CreditCard,
  Stethoscope,
  Package,
  HelpCircle
} from 'lucide-react';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Total Users',
      value: '12,543',
      change: '+12.5%',
      trend: 'up',
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      title: 'Total Orders',
      value: '8,234',
      change: '+8.2%',
      trend: 'up',
      icon: ShoppingCart,
      color: 'bg-green-500'
    },
    {
      title: 'Hospitals',
      value: '342',
      change: '+5.1%',
      trend: 'up',
      icon: Building2,
      color: 'bg-purple-500'
    },
    {
      title: 'Revenue',
      value: '$124,543',
      change: '-2.3%',
      trend: 'down',
      icon: DollarSign,
      color: 'bg-indigo-500'
    },
    {
      title: 'Active PreAuth',
      value: '1,234',
      change: '+15.3%',
      trend: 'up',
      icon: FileText,
      color: 'bg-rose-500'
    },
    {
      title: 'Insurance Claims',
      value: '5,678',
      change: '+9.7%',
      trend: 'up',
      icon: CreditCard,
      color: 'bg-yellow-500'
    },
    {
      title: 'Doctors',
      value: '456',
      change: '+3.2%',
      trend: 'up',
      icon: Stethoscope,
      color: 'bg-teal-500'
    },
    {
      title: 'Medicines',
      value: '12,345',
      change: '+7.8%',
      trend: 'up',
      icon: Package,
      color: 'bg-pink-500'
    }
  ];

  const insuranceData = [
    { company: 'Honey Badger', uploaded: 1800, active: 1, withApp: 0 },
    { company: 'Buffalo', uploaded: 297625, active: 5, withApp: 4 },
    { company: 'Jaquar', uploaded: 4584, active: 1002, withApp: 3 },
    { company: 'OM', uploaded: 791, active: 20, withApp: 3 },
    { company: 'Gorilla', uploaded: 23, active: 1, withApp: 1 }
  ];

  const recentActivities = [
    { id: 1, type: 'order', message: 'New order #12345 received', time: '2 minutes ago', status: 'success' },
    { id: 2, type: 'claim', message: 'Insurance claim #67890 approved', time: '15 minutes ago', status: 'success' },
    { id: 3, type: 'user', message: 'New hospital branch registered', time: '1 hour ago', status: 'info' },
    { id: 4, type: 'preauth', message: 'PreAuth request #11122 pending', time: '2 hours ago', status: 'warning' },
    { id: 5, type: 'payment', message: 'Payment processed for order #12345', time: '3 hours ago', status: 'success' }
  ];

  return (
    <div className="space-y-6">
      {/* Breadcrumbs */}
      <div className="text-sm text-gray-500 dark:text-gray-400">
        Home / Dashboard
      </div>

      {/* Page Title */}
      <h1 className="text-3xl font-bold text-gray-700 dark:text-gray-300">Dashboard</h1>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div
              key={index}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <Icon className="text-white" size={24} />
                </div>
                {stat.trend === 'up' ? (
                  <div className="flex items-center gap-1 text-green-600 dark:text-green-400">
                    <TrendingUp size={16} />
                    <span className="text-sm font-semibold">{stat.change}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-red-600 dark:text-red-400">
                    <TrendingDown size={16} />
                    <span className="text-sm font-semibold">{stat.change}</span>
                  </div>
                )}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{stat.title}</p>
            </div>
          );
        })}
      </div>

      {/* Charts and Activities Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Insured Livia Customers Table */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">
            Insured Livia Customers
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                    Insurance company
                  </th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                    <div className="flex items-center gap-1">
                      Uploaded members
                      <HelpCircle size={14} className="text-gray-400 cursor-help" />
                    </div>
                  </th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                    <div className="flex items-center gap-1">
                      Active members
                      <HelpCircle size={14} className="text-gray-400 cursor-help" />
                    </div>
                  </th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700 dark:text-gray-300">
                    <div className="flex items-center gap-1">
                      Members with Livia Health App
                      <HelpCircle size={14} className="text-gray-400 cursor-help" />
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {insuranceData.map((row, index) => (
                  <tr
                    key={index}
                    className="border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                  >
                    <td className="px-4 py-3 text-sm text-gray-800 dark:text-gray-200">
                      {row.company}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">
                      {row.uploaded.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">
                      {row.active.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-400">
                      {row.withApp.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Activities */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">Recent Activities</h2>
            <button className="text-sm text-teal-600 dark:text-teal-400 hover:underline">
              View All
            </button>
          </div>
          <div className="space-y-4">
            {recentActivities.map((activity) => (
              <div
                key={activity.id}
                className="flex items-start gap-4 p-4 rounded-lg bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              >
                <div
                  className={`w-2 h-2 rounded-full mt-2 ${
                    activity.status === 'success'
                      ? 'bg-green-500'
                      : activity.status === 'warning'
                      ? 'bg-yellow-500'
                      : 'bg-blue-500'
                  }`}
                />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{activity.message}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;