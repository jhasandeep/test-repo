import React, { useState, useEffect } from 'react';
import { Globe } from 'lucide-react';
import AdminLayout from '../../../components/admin/AdminLayout';
import CRUDPage, { FieldConfig } from '../../../components/admin/CRUDPage';
import DataTable, { Column } from '../../../components/admin/DataTable';
import { countryApi, Country } from '../../../services/api';

const Countries: React.FC = () => {
  const [countries, setCountries] = useState<Country[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadCountries();
  }, []);

  const loadCountries = async () => {
    try {
      setLoading(true);
      const data = await countryApi.getAll();
      setCountries(data);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to load countries');
      console.error('Error loading countries:', err);
    } finally {
      setLoading(false);
    }
  };

  const fields: FieldConfig[] = [
    { name: 'name', label: 'Country Name', type: 'text', required: true, placeholder: 'Enter country name' },
    { name: 'code', label: 'Country Code', type: 'text', required: true, placeholder: 'e.g., KE' },
    { name: 'currency', label: 'Currency', type: 'text', required: true, placeholder: 'e.g., KES' },
    {
      name: 'status',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { value: 'Active', label: 'Active' },
        { value: 'Inactive', label: 'Inactive' }
      ]
    }
  ];

  const columns: Column<Country>[] = [
    { header: 'ID', accessor: 'id', sortable: true },
    { header: 'Name', accessor: 'name', sortable: true },
    { header: 'Code', accessor: 'code', sortable: true },
    { header: 'Currency', accessor: 'currency', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active'
            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400'
            : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status || 'Active'}
        </span>
      ),
      sortable: true
    }
  ];

  const handleAdd = async (data: Partial<Country>) => {
    try {
      const newCountry = await countryApi.create({
        name: data.name as string,
        code: data.code as string,
        currency: data.currency,
        status: data.status || 'Active',
      } as Omit<Country, 'id'>);
      setCountries([newCountry, ...countries]);
    } catch (err: any) {
      throw new Error(err.message || 'Failed to create country');
    }
  };

  const handleEdit = async (id: number, data: Partial<Country>) => {
    try {
      const updated = await countryApi.update(id, data);
      setCountries(countries.map(country => country.id === id ? updated : country));
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update country');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await countryApi.delete(id);
      setCountries(countries.filter(country => country.id !== id));
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete country');
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Loading countries...</p>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-400">
          {error}
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <CRUDPage
        title="Countries"
        icon={Globe}
        description="Manage countries"
        fields={fields}
        data={countries}
        columns={columns}
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={handleDelete}
        searchPlaceholder="Search countries..."
      />
    </AdminLayout>
  );
};

export default Countries;

