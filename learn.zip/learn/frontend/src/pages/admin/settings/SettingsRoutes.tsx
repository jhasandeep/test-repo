import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AdminLayout from '../../../components/admin/AdminLayout';
import Countries from './Countries';
import GenericModulePage from '../../../pages/admin/GenericModulePage';
import { Settings, Globe } from 'lucide-react';
import { getModuleFields } from '../../../utils/moduleConfig';

const SettingsRoutes = () => (
  <AdminLayout>
    <Routes>
      <Route path="globals" element={<GenericModulePage title="Globals" icon={Settings} description="Global settings" fields={getModuleFields('Settings')} />} />
      <Route path="subscription" element={<GenericModulePage title="Subscription Setting" icon={Settings} description="Subscription settings" fields={getModuleFields('Settings')} />} />
      <Route path="countries" element={<Countries />} />
      <Route path="cities" element={<GenericModulePage title="Cities" icon={Globe} description="City management" fields={getModuleFields('Settings')} />} />
      <Route path="languages" element={<GenericModulePage title="Languages" icon={Globe} description="Language management" fields={getModuleFields('Settings')} />} />
      <Route path="insurance-companies" element={<GenericModulePage title="Insurance Companies" icon={Settings} description="Insurance companies management" fields={getModuleFields('Settings')} />} />
      <Route path="currencies" element={<GenericModulePage title="Currencies" icon={Settings} description="Currency management" fields={getModuleFields('Settings')} />} />
      <Route path="excel-parsing" element={<GenericModulePage title="Excel Parsing" icon={Settings} description="Excel parsing settings" fields={getModuleFields('Settings')} />} />
      <Route path="offices" element={<GenericModulePage title="Offices" icon={Settings} description="Office management" fields={getModuleFields('Settings')} />} />
      <Route path="partners" element={<GenericModulePage title="Partners" icon={Settings} description="Partner management" fields={getModuleFields('Settings')} />} />
      <Route path="app-versions" element={<GenericModulePage title="Application Versions" icon={Settings} description="Application version management" fields={getModuleFields('Settings')} />} />
      <Route path="geotag" element={<GenericModulePage title="Manage Skip Provider GeoTag" icon={Settings} description="Provider geotag settings" fields={getModuleFields('Settings')} />} />
    </Routes>
  </AdminLayout>
);

export default SettingsRoutes;



