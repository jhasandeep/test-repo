import React, { useState } from 'react';
import { FileText, Plus, Edit, Trash2 } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import ModulePage from '../../components/admin/ModulePage';
import DataTable, { Column } from '../../components/admin/DataTable';

interface BlogPost {
  id: number;
  title: string;
  author: string;
  category: string;
  status: string;
  publishedDate: string;
  views: number;
}

const BlogAdminManagement: React.FC = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);

  // Sample data
  const [posts] = useState<BlogPost[]>([
    {
      id: 1,
      title: 'Healthcare Innovation in 2025',
      author: 'Dr. John Smith',
      category: 'Healthcare',
      status: 'Published',
      publishedDate: '2025-01-15',
      views: 1250
    },
    {
      id: 2,
      title: 'Telemedicine Best Practices',
      author: 'Dr. Sarah Johnson',
      category: 'Telemedicine',
      status: 'Draft',
      publishedDate: '2025-01-20',
      views: 0
    },
    {
      id: 3,
      title: 'Patient Care Guidelines',
      author: 'Dr. Michael Brown',
      category: 'Patient Care',
      status: 'Published',
      publishedDate: '2025-01-18',
      views: 890
    }
  ]);

  const columns: Column<BlogPost>[] = [
    {
      header: 'Title',
      accessor: 'title',
      sortable: true
    },
    {
      header: 'Author',
      accessor: 'author',
      sortable: true
    },
    {
      header: 'Category',
      accessor: 'category',
      sortable: true
    },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Published' 
            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400'
            : 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    },
    {
      header: 'Published Date',
      accessor: 'publishedDate',
      sortable: true
    },
    {
      header: 'Views',
      accessor: 'views',
      sortable: true
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex gap-2">
          <button
            onClick={() => setEditingPost(row)}
            className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition-colors"
            title="Edit"
          >
            <Edit size={16} />
          </button>
          <button
            onClick={() => {
              if (window.confirm('Are you sure you want to delete this post?')) {
                // Handle delete
              }
            }}
            className="p-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
            title="Delete"
          >
            <Trash2 size={16} />
          </button>
        </div>
      ),
      sortable: false
    }
  ];

  return (
    <AdminLayout>
      <ModulePage title="Blog Admin Management" icon={FileText} description="Manage blog posts and content">
        <div className="space-y-6">
          {/* Action Bar */}
          <div className="flex justify-end items-center">
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-teal-500 hover:bg-teal-600 text-white font-semibold rounded-lg transition-colors"
            >
              <Plus size={20} />
              Add New Post
            </button>
          </div>

          {/* Data Table */}
          <DataTable
            data={posts}
            columns={columns}
            searchPlaceholder="Search blog posts..."
          />
        </div>

        {/* Add/Edit Modal */}
        {(showAddModal || editingPost) && (
          <BlogPostModal
            post={editingPost}
            onClose={() => {
              setShowAddModal(false);
              setEditingPost(null);
            }}
            onSave={(post) => {
              // Handle save
              setShowAddModal(false);
              setEditingPost(null);
            }}
          />
        )}
      </ModulePage>
    </AdminLayout>
  );
};

interface BlogPostModalProps {
  post: BlogPost | null;
  onClose: () => void;
  onSave: (post: Partial<BlogPost>) => void;
}

const BlogPostModal: React.FC<BlogPostModalProps> = ({ post, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    title: post?.title || '',
    author: post?.author || '',
    category: post?.category || '',
    status: post?.status || 'Draft',
    content: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">
            {post ? 'Edit Post' : 'Add New Post'}
          </h3>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
              Title
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Author
              </label>
              <input
                type="text"
                value={formData.author}
                onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                required
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Category
              </label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                required
                className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              >
                <option value="">Select Category</option>
                <option value="Healthcare">Healthcare</option>
                <option value="Telemedicine">Telemedicine</option>
                <option value="Patient Care">Patient Care</option>
                <option value="Technology">Technology</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
              Status
            </label>
            <select
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            >
              <option value="Draft">Draft</option>
              <option value="Published">Published</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
              Content
            </label>
            <textarea
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              rows={8}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
            />
          </div>
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              className="px-6 py-2 bg-teal-500 hover:bg-teal-600 text-white font-semibold rounded-lg transition-colors"
            >
              {post ? 'Update Post' : 'Create Post'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-semibold rounded-lg transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BlogAdminManagement;

