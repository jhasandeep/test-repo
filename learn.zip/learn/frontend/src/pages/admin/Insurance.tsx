import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Shield, Edit, Trash2, Eye, Download, Upload } from 'lucide-react';
import ModulePage from '../../components/admin/ModulePage';
import AdminLayout from '../../components/admin/AdminLayout';
import DataTable, { Column } from '../../components/admin/DataTable';
import { createSampleData } from '../../utils/generateModulePage';

// Sample data for different insurance modules
const eClaimsData = createSampleData(50, ['claimNumber', 'memberName', 'insuranceCompany', 'amount', 'status', 'date']);
const memberListData = createSampleData(100, ['memberId', 'name', 'email', 'phone', 'insuranceCompany', 'status']);
const prescriptionsData = createSampleData(75, ['prescriptionId', 'patientName', 'doctorName', 'date', 'status', 'amount']);

const EClaims = () => {
  const columns: Column<typeof eClaimsData[0]>[] = [
    { header: 'Claim Number', accessor: 'claimNumber', sortable: true },
    { header: 'Member Name', accessor: 'memberName', sortable: true },
    { header: 'Insurance Company', accessor: 'insuranceCompany', sortable: true },
    { header: 'Amount', accessor: 'amount', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' :
          row.status === 'Pending' ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400' :
          'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    },
    { header: 'Date', accessor: 'date', sortable: true }
  ];

  return (
    <ModulePage title="E-claims" icon={Shield} description="Electronic insurance claims management">
      <DataTable
        data={eClaimsData}
        columns={columns}
        searchPlaceholder="Search claims..."
        searchKeys={['claimNumber', 'memberName', 'insuranceCompany']}
        actions={(row) => (
          <div className="flex items-center gap-2">
            <button className="p-1 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded transition-colors">
              <Eye size={16} />
            </button>
            <button className="p-1 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded transition-colors">
              <Edit size={16} />
            </button>
          </div>
        )}
      />
    </ModulePage>
  );
};

const MemberList = () => {
  const columns: Column<typeof memberListData[0]>[] = [
    { header: 'Member ID', accessor: 'memberId', sortable: true },
    { header: 'Name', accessor: 'name', sortable: true },
    { header: 'Email', accessor: 'email', sortable: true },
    { header: 'Phone', accessor: 'phone' },
    { header: 'Insurance Company', accessor: 'insuranceCompany', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' :
          'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    }
  ];

  return (
    <ModulePage title="Member List" icon={Shield} description="Insurance member directory">
      <div className="mb-4 flex justify-end">
        <button className="flex items-center gap-2 px-4 py-2 bg-teal-500 hover:bg-teal-600 text-white rounded-lg transition-colors">
          <Upload size={18} />
          Import Members
        </button>
      </div>
      <DataTable
        data={memberListData}
        columns={columns}
        searchPlaceholder="Search members..."
        searchKeys={['memberId', 'name', 'email', 'insuranceCompany']}
      />
    </ModulePage>
  );
};

const Prescriptions = () => {
  const columns: Column<typeof prescriptionsData[0]>[] = [
    { header: 'Prescription ID', accessor: 'prescriptionId', sortable: true },
    { header: 'Patient Name', accessor: 'patientName', sortable: true },
    { header: 'Doctor Name', accessor: 'doctorName', sortable: true },
    { header: 'Date', accessor: 'date', sortable: true },
    { header: 'Amount', accessor: 'amount', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' :
          'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    }
  ];

  return (
    <ModulePage title="Prescriptions" icon={Shield} description="Insurance prescriptions management">
      <DataTable
        data={prescriptionsData}
        columns={columns}
        searchPlaceholder="Search prescriptions..."
        searchKeys={['prescriptionId', 'patientName', 'doctorName']}
      />
    </ModulePage>
  );
};

// Generic component for other insurance sub-modules
const GenericInsurancePage = ({ title, description }: { title: string; description: string }) => {
  const data = createSampleData(30, ['id', 'name', 'status', 'date', 'amount']);
  const columns: Column<typeof data[0]>[] = [
    { header: 'ID', accessor: 'id', sortable: true },
    { header: 'Name', accessor: 'name', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' :
          'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    },
    { header: 'Date', accessor: 'date', sortable: true },
    { header: 'Amount', accessor: 'amount', sortable: true }
  ];

  return (
    <ModulePage title={title} icon={Shield} description={description}>
      <DataTable
        data={data}
        columns={columns}
        searchPlaceholder={`Search ${title.toLowerCase()}...`}
      />
    </ModulePage>
  );
};

const InsuranceRoutes = () => (
  <AdminLayout>
    <Routes>
      <Route path="e-claims" element={<EClaims />} />
      <Route path="claim-reporting" element={<GenericInsurancePage title="Claim Reporting" description="Insurance claim reporting and analytics" />} />
      <Route path="offsystem-claims" element={<GenericInsurancePage title="Offsystem Claims" description="Claims from external systems" />} />
      <Route path="claims-otp" element={<GenericInsurancePage title="Claims Required OTP" description="Claims requiring OTP verification" />} />
      <Route path="sync-benefits" element={<GenericInsurancePage title="Sync Smart Benefits" description="Synchronize smart benefits data" />} />
      <Route path="template-claims" element={<GenericInsurancePage title="Template Claims" description="Claim templates management" />} />
      <Route path="member-list" element={<MemberList />} />
      <Route path="import-members" element={<GenericInsurancePage title="Import Members" description="Import insurance members from file" />} />
      <Route path="drugs" element={<GenericInsurancePage title="Insurance Drugs" description="Drugs covered by insurance" />} />
      <Route path="preauth-drugs" element={<GenericInsurancePage title="Preauth Drugs" description="Drugs requiring pre-authorization" />} />
      <Route path="ethical-substitute" element={<GenericInsurancePage title="Ethical Substitute" description="Ethical drug substitutes" />} />
      <Route path="import-benefit" element={<GenericInsurancePage title="Import Benefit" description="Import benefit data" />} />
      <Route path="import-ins-drugs" element={<GenericInsurancePage title="Import Ins Drugs" description="Import insurance drugs" />} />
      <Route path="prescriptions" element={<Prescriptions />} />
      <Route path="prepare-quotations" element={<GenericInsurancePage title="Prepare Quotations" description="Prepare insurance quotations" />} />
      <Route path="orders-delivery" element={<GenericInsurancePage title="Orders on Delivery" description="Insurance orders being delivered" />} />
      <Route path="refill-renewals" element={<GenericInsurancePage title="Refill Renewals" description="Prescription refill and renewal requests" />} />
      <Route path="link-smart-actisure" element={<GenericInsurancePage title="Link Smart-Actisure Number" description="Link Smart-Actisure numbers" />} />
    </Routes>
  </AdminLayout>
);

export default InsuranceRoutes;


