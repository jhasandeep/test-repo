import React from 'react';
import { LucideIcon } from 'lucide-react';
import ModulePage from '../../components/admin/ModulePage';
import DataTable, { Column } from '../../components/admin/DataTable';
import { createSampleData } from '../../utils/generateModulePage';

interface GenericModulePageProps {
  title: string;
  icon: LucideIcon;
  description: string;
  fields?: string[];
  customColumns?: Column<any>[];
  dataCount?: number;
}

const GenericModulePage: React.FC<GenericModulePageProps> = ({
  title,
  icon,
  description,
  fields = ['id', 'name', 'status', 'date'],
  customColumns,
  dataCount = 30
}) => {
  const data = createSampleData(dataCount, fields);

  const columns: Column<any>[] = customColumns || fields.map(field => {
    if (field.includes('status') || field.includes('Status')) {
      return {
        header: field.charAt(0).toUpperCase() + field.slice(1),
        accessor: (row: any) => (
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
            row[field] === 'Active' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' :
            row[field] === 'Pending' ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400' :
            'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
          }`}>
            {row[field]}
          </span>
        ),
        sortable: true
      };
    }
    return {
      header: field.charAt(0).toUpperCase() + field.slice(1),
      accessor: field as keyof typeof data[0],
      sortable: true
    };
  });

  return (
    <ModulePage title={title} icon={icon} description={description}>
      <DataTable
        data={data}
        columns={columns}
        searchPlaceholder={`Search ${title.toLowerCase()}...`}
      />
    </ModulePage>
  );
};

export default GenericModulePage;


