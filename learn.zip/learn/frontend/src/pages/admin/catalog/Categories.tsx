import React, { useState, useEffect } from 'react';
import { Package } from 'lucide-react';
import AdminLayout from '../../../components/admin/AdminLayout';
import CRUDPage, { FieldConfig } from '../../../components/admin/CRUDPage';
import DataTable, { Column } from '../../../components/admin/DataTable';
import { categoryApi, Category } from '../../../services/api';

const Categories: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      setLoading(true);
      const data = await categoryApi.getAll();
      setCategories(data);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to load categories');
      console.error('Error loading categories:', err);
    } finally {
      setLoading(false);
    }
  };

  const fields: FieldConfig[] = [
    { name: 'name', label: 'Category Name', type: 'text', required: true, placeholder: 'Enter category name' },
    { name: 'description', label: 'Description', type: 'textarea', placeholder: 'Enter description' },
    {
      name: 'status',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { value: 'Active', label: 'Active' },
        { value: 'Inactive', label: 'Inactive' }
      ]
    }
  ];

  const columns: Column<Category>[] = [
    { header: 'ID', accessor: 'id', sortable: true },
    { header: 'Name', accessor: 'name', sortable: true },
    { header: 'Description', accessor: 'description', sortable: false },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active'
            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400'
            : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    },
    { 
      header: 'Created At', 
      accessor: (row) => row.createdAt ? new Date(row.createdAt).toLocaleDateString() : '-', 
      sortable: true 
    }
  ];

  const handleAdd = async (data: Partial<Category>) => {
    try {
      const newCategory = await categoryApi.create({
        name: data.name as string,
        description: data.description,
        status: data.status || 'Active',
      } as Omit<Category, 'id'>);
      setCategories([newCategory, ...categories]);
    } catch (err: any) {
      throw new Error(err.message || 'Failed to create category');
    }
  };

  const handleEdit = async (id: number, data: Partial<Category>) => {
    try {
      const updated = await categoryApi.update(id, data);
      setCategories(categories.map(cat => cat.id === id ? updated : cat));
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update category');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await categoryApi.delete(id);
      setCategories(categories.filter(cat => cat.id !== id));
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete category');
    }
  };

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-teal-500"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Loading categories...</p>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg text-red-700 dark:text-red-400">
          {error}
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <CRUDPage
        title="Categories"
        icon={Package}
        description="Manage product categories"
        fields={fields}
        data={categories}
        columns={columns}
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={handleDelete}
        searchPlaceholder="Search categories..."
      />
    </AdminLayout>
  );
};

export default Categories;

