import React from 'react';
import { Routes, Route } from 'react-router-dom';
import AdminLayout from '../../../components/admin/AdminLayout';
import Categories from './Categories';
import GenericModulePage from '../../../pages/admin/GenericModulePage';
import { Package } from 'lucide-react';
import { getModuleFields } from '../../../utils/moduleConfig';

const CatalogRoutes = () => (
  <AdminLayout>
    <Routes>
      <Route path="categories" element={<Categories />} />
      <Route path="subcategories" element={<GenericModulePage title="Subcategories" icon={Package} description="Manage subcategories" fields={getModuleFields('Catalog')} />} />
      <Route path="medicines" element={<GenericModulePage title="Medicines" icon={Package} description="Manage medicines" fields={getModuleFields('Catalog')} />} />
      <Route path="insurance-formulary" element={<GenericModulePage title="Manage Insurance Formulary" icon={Package} description="Insurance formulary management" fields={getModuleFields('Catalog')} />} />
      <Route path="regular-formulary" element={<GenericModulePage title="Manage Regular Formulary" icon={Package} description="Regular formulary management" fields={getModuleFields('Catalog')} />} />
      <Route path="personal-items" element={<GenericModulePage title="Personal Items" icon={Package} description="Personal items management" fields={getModuleFields('Catalog')} />} />
      <Route path="drug-index" element={<GenericModulePage title="Drug Index" icon={Package} description="Drug index management" fields={getModuleFields('Catalog')} />} />
      <Route path="banners" element={<GenericModulePage title="Banners" icon={Package} description="Banner management" fields={getModuleFields('Catalog')} />} />
    </Routes>
  </AdminLayout>
);

export default CatalogRoutes;



