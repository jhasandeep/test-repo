import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Building2 } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import CRUDPage, { FieldConfig } from '../../components/admin/CRUDPage';
import DataTable, { Column } from '../../components/admin/DataTable';
import ModulePage from '../../components/admin/ModulePage';

// Sample data
interface Branch {
  id: number;
  name: string;
  location: string;
  status: string;
  phone: string;
  email: string;
}

interface HospitalUser {
  id: number;
  name: string;
  email: string;
  role: string;
  branch: string;
  status: string;
}

const Branches = () => {
  const [branches, setBranches] = useState<Branch[]>([
    { id: 1, name: 'Main Branch', location: 'Nairobi, Kenya', status: 'Active', phone: '+254 712 345 678', email: 'main@hospital.com' },
    { id: 2, name: 'Westlands Branch', location: 'Westlands, Nairobi', status: 'Active', phone: '+254 712 345 679', email: 'westlands@hospital.com' },
    { id: 3, name: 'Kisumu Branch', location: 'Kisumu, Kenya', status: 'Inactive', phone: '+254 712 345 680', email: 'kisumu@hospital.com' }
  ]);

  const fields: FieldConfig[] = [
    { name: 'name', label: 'Branch Name', type: 'text', required: true, placeholder: 'Enter branch name' },
    { name: 'location', label: 'Location', type: 'text', required: true, placeholder: 'Enter location' },
    { name: 'phone', label: 'Phone', type: 'text', required: true, placeholder: '+254 712 345 678' },
    { name: 'email', label: 'Email', type: 'email', required: true, placeholder: 'branch@hospital.com' },
    {
      name: 'status',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { value: 'Active', label: 'Active' },
        { value: 'Inactive', label: 'Inactive' }
      ]
    }
  ];

  const columns: Column<Branch>[] = [
    { header: 'Name', accessor: 'name', sortable: true },
    { header: 'Location', accessor: 'location', sortable: true },
    { header: 'Phone', accessor: 'phone' },
    { header: 'Email', accessor: 'email' },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active' 
            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' 
            : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    }
  ];

  const handleAdd = async (data: Partial<Branch>) => {
    const newBranch: Branch = {
      id: branches.length + 1,
      name: data.name as string,
      location: data.location as string,
      phone: data.phone as string,
      email: data.email as string,
      status: data.status as string
    };
    setBranches([...branches, newBranch]);
  };

  const handleEdit = async (id: number, data: Partial<Branch>) => {
    setBranches(branches.map(branch => branch.id === id ? { ...branch, ...data } as Branch : branch));
  };

  const handleDelete = async (id: number) => {
    setBranches(branches.filter(branch => branch.id !== id));
  };

  return (
    <CRUDPage
      title="Branches"
      icon={Building2}
      description="Manage hospital branches"
      fields={fields}
      data={branches}
      columns={columns}
      onAdd={handleAdd}
      onEdit={handleEdit}
      onDelete={handleDelete}
      searchPlaceholder="Search branches..."
    />
  );
};

const requestsData = [
  { id: 1, hospitalName: 'City Hospital', location: 'Nairobi', requestedBy: 'John Doe', date: '2025-01-15', status: 'Pending' },
  { id: 2, hospitalName: 'Metro Clinic', location: 'Mombasa', requestedBy: 'Jane Smith', date: '2025-01-14', status: 'Pending' },
  { id: 3, hospitalName: 'Community Health', location: 'Kisumu', requestedBy: 'Mike Johnson', date: '2025-01-13', status: 'Under Review' }
];

const declinedData = [
  { id: 1, hospitalName: 'Test Hospital', location: 'Nairobi', requestedBy: 'Test User', date: '2025-01-10', reason: 'Incomplete documentation' },
  { id: 2, hospitalName: 'Sample Clinic', location: 'Eldoret', requestedBy: 'Sample User', date: '2025-01-08', reason: 'Invalid credentials' }
];

const Requests = () => {
  const columns: Column<typeof requestsData[0]>[] = [
    { header: 'Hospital Name', accessor: 'hospitalName', sortable: true },
    { header: 'Location', accessor: 'location', sortable: true },
    { header: 'Requested By', accessor: 'requestedBy', sortable: true },
    { header: 'Date', accessor: 'date', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Pending' 
            ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400'
            : 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    }
  ];

  return (
    <ModulePage title="Requests" icon={Building2} description="Hospital registration requests">
      <DataTable
        data={requestsData}
        columns={columns}
        searchPlaceholder="Search requests..."
        actions={(row) => (
          <div className="flex items-center gap-2">
            <button className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700 transition-colors">
              Approve
            </button>
            <button className="px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700 transition-colors">
              Decline
            </button>
          </div>
        )}
      />
    </ModulePage>
  );
};

const Declined = () => {
  const columns: Column<typeof declinedData[0]>[] = [
    { header: 'Hospital Name', accessor: 'hospitalName', sortable: true },
    { header: 'Location', accessor: 'location', sortable: true },
    { header: 'Requested By', accessor: 'requestedBy', sortable: true },
    { header: 'Date', accessor: 'date', sortable: true },
    { header: 'Reason', accessor: 'reason' }
  ];

  return (
    <ModulePage title="Declined" icon={Building2} description="Declined hospital registrations">
      <DataTable
        data={declinedData}
        columns={columns}
        searchPlaceholder="Search declined requests..."
      />
    </ModulePage>
  );
};

const HospitalUsers = () => {
  const [users, setUsers] = useState<HospitalUser[]>([
    { id: 1, name: 'Dr. Sarah Kimani', email: 'sarah@hospital.com', role: 'Administrator', branch: 'Main Branch', status: 'Active' },
    { id: 2, name: 'John Mwangi', email: 'john@hospital.com', role: 'Manager', branch: 'Westlands Branch', status: 'Active' },
    { id: 3, name: 'Mary Wanjiku', email: 'mary@hospital.com', role: 'Staff', branch: 'Main Branch', status: 'Inactive' }
  ]);

  const fields: FieldConfig[] = [
    { name: 'name', label: 'Full Name', type: 'text', required: true, placeholder: 'Enter full name' },
    { name: 'email', label: 'Email', type: 'email', required: true, placeholder: 'user@hospital.com' },
    {
      name: 'role',
      label: 'Role',
      type: 'select',
      required: true,
      options: [
        { value: 'Administrator', label: 'Administrator' },
        { value: 'Manager', label: 'Manager' },
        { value: 'Staff', label: 'Staff' }
      ]
    },
    { name: 'branch', label: 'Branch', type: 'text', required: true, placeholder: 'Enter branch name' },
    {
      name: 'status',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { value: 'Active', label: 'Active' },
        { value: 'Inactive', label: 'Inactive' }
      ]
    }
  ];

  const columns: Column<HospitalUser>[] = [
    { header: 'Name', accessor: 'name', sortable: true },
    { header: 'Email', accessor: 'email', sortable: true },
    { header: 'Role', accessor: 'role', sortable: true },
    { header: 'Branch', accessor: 'branch', sortable: true },
    {
      header: 'Status',
      accessor: (row) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
          row.status === 'Active' 
            ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400' 
            : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-400'
        }`}>
          {row.status}
        </span>
      ),
      sortable: true
    }
  ];

  const handleAdd = async (data: Partial<HospitalUser>) => {
    const newUser: HospitalUser = {
      id: users.length + 1,
      name: data.name as string,
      email: data.email as string,
      role: data.role as string,
      branch: data.branch as string,
      status: data.status as string
    };
    setUsers([...users, newUser]);
  };

  const handleEdit = async (id: number, data: Partial<HospitalUser>) => {
    setUsers(users.map(user => user.id === id ? { ...user, ...data } as HospitalUser : user));
  };

  const handleDelete = async (id: number) => {
    setUsers(users.filter(user => user.id !== id));
  };

  return (
    <CRUDPage
      title="Hospital Users"
      icon={Building2}
      description="Manage hospital users"
      fields={fields}
      data={users}
      columns={columns}
      onAdd={handleAdd}
      onEdit={handleEdit}
      onDelete={handleDelete}
      searchPlaceholder="Search users..."
    />
  );
};

const BusinessHospitalsRoutes = () => (
  <AdminLayout>
    <Routes>
      <Route path="branches" element={<Branches />} />
      <Route path="requests" element={<Requests />} />
      <Route path="declined" element={<Declined />} />
      <Route path="users" element={<HospitalUsers />} />
    </Routes>
  </AdminLayout>
);

export default BusinessHospitalsRoutes;