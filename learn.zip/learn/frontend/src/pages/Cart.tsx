import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, Minus, Plus, ShoppingBag } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

const Cart: React.FC = () => {
  const { cartItems, removeFromCart, updateQuantity, getTotalPrice, clearCart } = useCart();
  const navigate = useNavigate();

  if (cartItems.length === 0) {
    return (
      <div className="pt-24 pb-20 min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="max-w-md w-full mx-auto px-4 text-center">
            <div className="bg-white rounded-2xl shadow-xl p-12 border border-gray-100">
              <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <ShoppingBag className="w-10 h-10 text-indigo-600" />
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-3">Your cart is empty</h3>
              <p className="text-gray-600 mb-8">Start shopping to add items to your cart</p>
              <button
                onClick={() => navigate('/')}
                className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg shadow-indigo-600/30"
              >
                Continue Shopping
              </button>
            </div>
          </div>
        </div>
    );
  }

  const subtotal = getTotalPrice();
  const shipping = 10.00;
  const tax = subtotal * 0.1;
  const total = subtotal + shipping + tax;

  return (
    <div className="pt-24 pb-20 min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h2 className="text-4xl font-black text-gray-900 mb-12">Shopping Cart</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 flex flex-col sm:flex-row gap-6 hover:shadow-lg transition-all duration-300"
                >
                  {/* Image */}
                  <div className="w-full sm:w-32 h-32 bg-gray-50 rounded-xl flex items-center justify-center flex-shrink-0">
                    {item.emoji ? (
                      <span className="text-5xl">{item.emoji}</span>
                    ) : (
                      <ShoppingBag className="w-12 h-12 text-gray-400" />
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 flex flex-col sm:flex-row sm:justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{item.name}</h3>
                      <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                      <div className="text-2xl font-black text-indigo-600">${item.price.toFixed(2)}</div>
                    </div>

                    {/* Quantity & Actions */}
                    <div className="flex items-center gap-4 sm:flex-col sm:items-end">
                      <div className="flex items-center gap-3 bg-gray-100 rounded-lg p-1">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="w-8 h-8 rounded-lg bg-white hover:bg-indigo-600 hover:text-white transition-colors flex items-center justify-center"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="w-8 text-center font-bold text-gray-900">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 rounded-lg bg-white hover:bg-indigo-600 hover:text-white transition-colors flex items-center justify-center"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>

                  {/* Total */}
                  <div className="sm:text-right">
                    <div className="text-2xl font-black text-gray-900">
                      ${(item.price * item.quantity).toFixed(2)}
                    </div>
                  </div>
                </div>
              ))}

              <button
                onClick={clearCart}
                className="w-full sm:w-auto px-6 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-bold transition-colors flex items-center justify-center gap-2"
              >
                <Trash2 size={18} /> Clear Cart
              </button>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 sticky top-24">
                <h3 className="text-2xl font-black text-gray-900 mb-6">Order Summary</h3>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between text-gray-600">
                    <span>Subtotal</span>
                    <span className="font-bold">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Shipping</span>
                    <span className="font-bold">${shipping.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-gray-600">
                    <span>Tax</span>
                    <span className="font-bold">${tax.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4 flex justify-between text-xl font-black text-gray-900">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>

                <button
                  onClick={() => navigate('/checkout')}
                  className="w-full px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg shadow-indigo-600/30 mb-4"
                >
                  Proceed to Checkout
                </button>
                <button
                  onClick={() => navigate('/')}
                  className="w-full px-8 py-4 bg-transparent border-2 border-gray-300 hover:border-gray-400 text-gray-700 rounded-lg font-bold transition-all"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
};

export default Cart;