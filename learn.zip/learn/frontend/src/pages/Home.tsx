import React, { useState } from 'react';
import Hero from '../components/Hero';
import Features from '../components/Features';
import ProductsSection from '../components/ProductsSection';
import Newsletter from '../components/Newsletter';
import CartSidebar from '../components/CartSidebar';

const Home: React.FC = () => {
  const [isCartOpen, setIsCartOpen] = useState(false);

  const handleShopClick = () => {
    document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <Hero onShopClick={handleShopClick} />
      <Features />
      <ProductsSection onCartOpen={() => setIsCartOpen(true)} />
      <Newsletter />
      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
};

export default Home;