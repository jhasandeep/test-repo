import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to include auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Unauthorized - clear token and redirect to login
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authApi = {
  login: async (email: string, password: string, otp?: string) => {
    const response = await apiClient.post('/auth/login', { email, password, otp });
    return response.data;
  },

  register: async (name: string, email: string, password: string) => {
    const response = await apiClient.post('/auth/register', { name, email, password });
    return response.data;
  },
};

// Users API
export interface User {
  id: number;
  name: string;
  email: string;
  data?: string[];
}

export interface CreateUserDto {
  name: string;
  email: string;
  data?: string[];
}

export interface UpdateUserDto {
  name?: string;
  email?: string;
  data?: string[];
}

export const userApi = {
  getAll: async (): Promise<User[]> => {
    const response = await apiClient.get<User[]>('/users');
    return response.data;
  },

  getById: async (id: number): Promise<User> => {
    const response = await apiClient.get<User>(`/users/${id}`);
    return response.data;
  },

  create: async (user: CreateUserDto): Promise<string> => {
    const response = await apiClient.post<string>('/users/create', user);
    return response.data;
  },

  update: async (id: number, user: UpdateUserDto): Promise<any> => {
    const response = await apiClient.patch(`/users/update/${id}`, user);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/users/delete/${id}`);
  },
};

// Generic API for CRUD operations
export const createGenericApi = <T extends { id: number }>(endpoint: string) => ({
  getAll: async (): Promise<T[]> => {
    const response = await apiClient.get<T[]>(`/${endpoint}`);
    return response.data;
  },

  getById: async (id: number): Promise<T> => {
    const response = await apiClient.get<T>(`/${endpoint}/${id}`);
    return response.data;
  },

  create: async (data: Omit<T, 'id'>): Promise<T> => {
    const response = await apiClient.post<T>(`/${endpoint}`, data);
    return response.data;
  },

  update: async (id: number, data: Partial<T>): Promise<T> => {
    const response = await apiClient.patch<T>(`/${endpoint}/${id}`, data);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/${endpoint}/${id}`);
  },
});

// Hospital Branches API
export interface HospitalBranch {
  id: number;
  hospitalName: string;
  physicalAddress: string;
  url?: string;
  fullName: string;
  email: string;
  mobileNumber: string;
  status: string;
  requestDate: string;
}

export const hospitalBranchApi = createGenericApi<HospitalBranch>('hospital-branches');

// Categories API
export interface Category {
  id: number;
  name: string;
  description?: string;
  status?: string;
  createdAt?: string | Date;
  updatedAt?: string | Date;
}

export const categoryApi = createGenericApi<Category>('categories');

// Countries API
export interface Country {
  id: number;
  name: string;
  code: string;
  currency?: string;
  flag?: string;
  status?: string;
  createdAt?: string | Date;
  updatedAt?: string | Date;
}

export const countryApi = createGenericApi<Country>('countries');

export default apiClient;
