import React, { useState } from 'react';
import { ShoppingBag, Minus, Plus } from 'lucide-react';

interface AddToCartProps {
  price: number;
  onAddToCart: (quantity: number) => void;
  disabled?: boolean;
  productName?: string;
}

const AddToCart: React.FC<AddToCartProps> = ({
  price,
  onAddToCart,
  disabled = false,
  productName = 'Product'
}) => {
  const [quantity, setQuantity] = useState(1);

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity < 1) return;
    setQuantity(newQuantity);
  };

  const handleAddToCart = () => {
    onAddToCart(quantity);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Glass Panel Container */}
      <div className="bg-slate-900 rounded-2xl p-8 border border-white/10 backdrop-blur-md bg-white/5 shadow-2xl">
        
        {/* Price Display */}
        <div className="mb-6">
          <p className="text-sm text-gray-400 uppercase tracking-wider mb-2 font-bold">Price</p>
          <div className="text-4xl md:text-5xl font-black text-white tracking-tight">
            ${price.toFixed(2)}
          </div>
        </div>

        {/* Quantity Selector */}
        <div className="mb-6">
          <p className="text-sm text-gray-400 uppercase tracking-wider mb-3 font-bold">Quantity</p>
          <div className="flex items-center justify-between bg-white/5 rounded-full p-1 border border-white/10">
            <button
              onClick={() => handleQuantityChange(quantity - 1)}
              disabled={quantity <= 1 || disabled}
              className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-white transition-all duration-200 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:scale-110 active:scale-95"
              aria-label="Decrease quantity"
            >
              <Minus size={20} strokeWidth={3} />
            </button>
            
            <span className="text-2xl font-black text-white min-w-[60px] text-center">
              {quantity}
            </span>
            
            <button
              onClick={() => handleQuantityChange(quantity + 1)}
              disabled={disabled}
              className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 active:bg-white/30 text-white transition-all duration-200 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:scale-110 active:scale-95"
              aria-label="Increase quantity"
            >
              <Plus size={20} strokeWidth={3} />
            </button>
          </div>
        </div>

        {/* Subtotal (Optional) */}
        <div className="mb-6 pb-6 border-b border-white/10">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400 uppercase tracking-wider font-bold">Subtotal</span>
            <span className="text-xl font-black text-white">
              ${(price * quantity).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Add to Cart Button */}
        <button
          onClick={handleAddToCart}
          disabled={disabled}
          className="w-full py-4 px-8 bg-gradient-to-r from-indigo-600 to-rose-500 rounded-full text-white font-black text-lg uppercase tracking-wide transition-all duration-300 transform hover:scale-105 active:scale-95 hover:shadow-[0_0_30px_rgba(99,102,241,0.5)] hover:shadow-rose-500/50 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:hover:shadow-none flex items-center justify-center gap-3 group"
          aria-label={`Add ${quantity} ${productName}${quantity > 1 ? 's' : ''} to cart`}
        >
          <ShoppingBag 
            size={22} 
            className="transition-transform duration-300 group-hover:scale-110" 
            strokeWidth={2.5}
          />
          <span>Add to Cart</span>
        </button>

        {/* Additional Info (Optional) */}
        <div className="mt-6 pt-6 border-t border-white/10">
          <p className="text-xs text-gray-400 text-center">
            Free shipping on orders over $150
          </p>
        </div>
      </div>
    </div>
  );
};

export default AddToCart;



