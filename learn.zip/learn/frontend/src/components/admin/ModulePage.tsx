import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ModulePageProps {
  title: string;
  icon?: LucideIcon;
  description?: string;
  children?: React.ReactNode;
}

const ModulePage: React.FC<ModulePageProps> = ({ title, icon: Icon, description, children }) => {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            {Icon && (
              <div className="p-2 bg-indigo-100 dark:bg-indigo-900/30 rounded-lg">
                <Icon className="text-indigo-600 dark:text-indigo-400" size={24} />
              </div>
            )}
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{title}</h1>
          </div>
          {description && (
            <p className="text-gray-500 dark:text-gray-400 mt-2">{description}</p>
          )}
        </div>
      </div>

      {/* Content */}
      {children || (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
          <p className="text-gray-500 dark:text-gray-400">This module is under development.</p>
        </div>
      )}
    </div>
  );
};

export default ModulePage;


