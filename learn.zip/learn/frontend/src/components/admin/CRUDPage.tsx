import React, { useState } from 'react';
import { Plus, Edit, Trash2, Save, X } from 'lucide-react';
import { LucideIcon } from 'lucide-react';
import ModulePage from './ModulePage';
import DataTable, { Column } from './DataTable';

export interface FieldConfig {
  name: string;
  label: string;
  type: 'text' | 'email' | 'number' | 'select' | 'textarea' | 'date' | 'checkbox';
  required?: boolean;
  options?: { value: string; label: string }[];
  placeholder?: string;
}

interface CRUDPageProps {
  title: string;
  icon: LucideIcon;
  description: string;
  fields: FieldConfig[];
  data: any[];
  columns: Column<any>[];
  onAdd?: (data: any) => void | Promise<void>;
  onEdit?: (id: number, data: any) => void | Promise<void>;
  onDelete?: (id: number) => void | Promise<void>;
  searchPlaceholder?: string;
}

const CRUDPage: React.FC<CRUDPageProps> = ({
  title,
  icon,
  description,
  fields,
  data,
  columns,
  onAdd,
  onEdit,
  onDelete,
  searchPlaceholder = 'Search...'
}) => {
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<any | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAdd = () => {
    setEditingItem(null);
    const initialData: Record<string, any> = {};
    fields.forEach(field => {
      initialData[field.name] = field.type === 'checkbox' ? false : '';
    });
    setFormData(initialData);
    setShowModal(true);
  };

  const handleEdit = (item: any) => {
    setEditingItem(item);
    const initialData: Record<string, any> = {};
    fields.forEach(field => {
      initialData[field.name] = item[field.name] || (field.type === 'checkbox' ? false : '');
    });
    setFormData(initialData);
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      if (onDelete) {
        await onDelete(id);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (editingItem && onEdit) {
        await onEdit(editingItem.id, formData);
      } else if (onAdd) {
        await onAdd(formData);
      }
      setShowModal(false);
      setEditingItem(null);
      setFormData({});
    } catch (error: any) {
      setError(error.message || 'An error occurred while saving');
      console.error('Error saving:', error);
    } finally {
      setLoading(false);
    }
  };

  // Add actions column if onEdit or onDelete is provided
  const tableColumns: Column<any>[] = [
    ...columns,
    ...((onEdit || onDelete) ? [{
      header: 'Actions',
      accessor: (row: any) => (
        <div className="flex gap-2">
          {onEdit && (
            <button
              onClick={() => handleEdit(row)}
              className="p-1.5 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition-colors"
              title="Edit"
            >
              <Edit size={16} />
            </button>
          )}
          {onDelete && (
            <button
              onClick={() => handleDelete(row.id)}
              className="p-1.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
              title="Delete"
            >
              <Trash2 size={16} />
            </button>
          )}
        </div>
      ),
      sortable: false
    }] : [])
  ];

  return (
    <ModulePage title={title} icon={icon} description={description}>
      <div className="space-y-6">
        {/* Action Bar */}
        <div className="flex justify-end items-center">
          {onAdd && (
            <button
              onClick={handleAdd}
              className="flex items-center gap-2 px-4 py-2 bg-teal-500 hover:bg-teal-600 text-white font-semibold rounded-lg transition-colors"
            >
              <Plus size={20} />
              Add New
            </button>
          )}
        </div>

        {/* Data Table */}
        <DataTable
          data={data}
          columns={tableColumns}
          searchPlaceholder={searchPlaceholder}
        />
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <CRUDModal
          title={editingItem ? `Edit ${title}` : `Add New ${title}`}
          fields={fields}
          formData={formData}
          setFormData={setFormData}
          onSubmit={handleSubmit}
          onClose={() => {
            setShowModal(false);
            setEditingItem(null);
            setFormData({});
            setError(null);
          }}
          loading={loading}
          error={error}
        />
      )}
    </ModulePage>
  );
};

interface CRUDModalProps {
  title: string;
  fields: FieldConfig[];
  formData: Record<string, any>;
  setFormData: (data: Record<string, any>) => void;
  onSubmit: (e: React.FormEvent) => void;
  onClose: () => void;
  loading: boolean;
  error?: string | null;
}

const CRUDModal: React.FC<CRUDModalProps> = ({
  title,
  fields,
  formData,
  setFormData,
  onSubmit,
  onClose,
  loading,
  error
}) => {
  const renderField = (field: FieldConfig) => {
    const commonClasses = "w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white";

    switch (field.type) {
      case 'textarea':
        return (
          <textarea
            value={formData[field.name] || ''}
            onChange={(e) => setFormData({ ...formData, [field.name]: e.target.value })}
            required={field.required}
            placeholder={field.placeholder}
            rows={4}
            className={commonClasses}
          />
        );
      case 'select':
        return (
          <select
            value={formData[field.name] || ''}
            onChange={(e) => setFormData({ ...formData, [field.name]: e.target.value })}
            required={field.required}
            className={commonClasses}
          >
            <option value="">Select {field.label}</option>
            {field.options?.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        );
      case 'checkbox':
        return (
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData[field.name] || false}
              onChange={(e) => setFormData({ ...formData, [field.name]: e.target.checked })}
              className="w-4 h-4 text-teal-600 rounded focus:ring-teal-500"
            />
            <span className="text-sm text-gray-700 dark:text-gray-300">{field.label}</span>
          </label>
        );
      default:
        return (
          <input
            type={field.type}
            value={formData[field.name] || ''}
            onChange={(e) => setFormData({ ...formData, [field.name]: e.target.value })}
            required={field.required}
            placeholder={field.placeholder}
            className={commonClasses}
          />
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{title}</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
          >
            <X size={20} className="text-gray-500 dark:text-gray-400" />
          </button>
        </div>
        <form onSubmit={onSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded text-red-700 dark:text-red-400 text-sm">
              {error}
            </div>
          )}
          {fields.map((field) => (
            <div key={field.name}>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                {field.label} {field.required && <span className="text-red-500">*</span>}
              </label>
              {renderField(field)}
            </div>
          ))}
          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 px-6 py-2 bg-teal-500 hover:bg-teal-600 text-white font-semibold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save size={18} />
              {loading ? 'Saving...' : 'Save'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex items-center gap-2 px-6 py-2 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 font-semibold rounded-lg transition-colors"
            >
              <X size={18} />
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CRUDPage;

