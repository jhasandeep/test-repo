import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  LayoutDashboard,
  Building2,
  Shield,
  FileText,
  ShoppingCart,
  Image,
  Users,
  CreditCard,
  Factory,
  BarChart3,
  Calendar,
  Star,
  Package,
  ClipboardList,
  Truck,
  Stethoscope,
  Search as SearchIcon,
  Settings,
  Menu,
  X,
  LogOut,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Globe,
  Lock,
  List,
  UserCheck,
  XCircle,
  User,
  FileCheck,
  Upload,
  Pill,
  Heart,
  Receipt,
  PackageSearch,
  ClipboardCheck,
  MapPin,
  DollarSign,
  Activity,
  TrendingUp,
  Code,
  BookOpen,
  Mail,
  Key,
  Eye,
  Database,
  Smartphone,
  Hospital,
  MessageSquare,
  HelpCircle,
  Wallet,
  ArrowRightLeft,
  AlertCircle,
  CheckCircle,
  Clock,
  Zap,
  Target,
  Timer,
  FileX
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import ThemeToggle from '../ThemeToggle';
import { getModuleCount, getSubModuleCount } from '../../utils/moduleCounts';
import { getSubModuleIcon } from '../../utils/subModuleIcons';
import { languages, getLanguageByCode } from '../../utils/languages';
import './AdminLayout.css';

interface AdminLayoutProps {
  children: React.ReactNode;
}

interface MenuItem {
  icon: React.ElementType;
  label: string;
  path?: string;
  count?: number;
  subItems?: { label: string; path: string; count?: number; icon?: React.ElementType }[];
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const { t, i18n } = useTranslation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState<Set<string>>(new Set());
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const currentLanguage = getLanguageByCode(i18n.language) || languages[0];

  const handleLanguageChange = (langCode: string) => {
    i18n.changeLanguage(langCode);
    // Set RTL for Arabic
    if (langCode === 'ar') {
      document.documentElement.setAttribute('dir', 'rtl');
    } else {
      document.documentElement.setAttribute('dir', 'ltr');
    }
  };

  // Set initial direction based on current language
  React.useEffect(() => {
    if (i18n.language === 'ar') {
      document.documentElement.setAttribute('dir', 'rtl');
    } else {
      document.documentElement.setAttribute('dir', 'ltr');
    }
  }, [i18n.language]);

  const menuItems: MenuItem[] = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/admin', count: getModuleCount('Dashboard') },
    {
      icon: Building2,
      label: 'Business Hospitals',
      count: getModuleCount('Business Hospitals'),
      subItems: [
        { label: 'Branches', path: '/admin/business-hospitals/branches', count: getSubModuleCount('Business Hospitals', 'Branches') },
        { label: 'Requests', path: '/admin/business-hospitals/requests', count: getSubModuleCount('Business Hospitals', 'Requests') },
        { label: 'Declined', path: '/admin/business-hospitals/declined', count: getSubModuleCount('Business Hospitals', 'Declined') },
        { label: 'Hospital Users', path: '/admin/business-hospitals/users', count: getSubModuleCount('Business Hospitals', 'Hospital Users') }
      ]
    },
    {
      icon: Shield,
      label: 'Insurance',
      count: getModuleCount('Insurance'),
      subItems: [
        { label: 'E-claims', path: '/admin/insurance/e-claims', count: getSubModuleCount('Insurance', 'E-claims') },
        { label: 'Claim Reporting', path: '/admin/insurance/claim-reporting', count: getSubModuleCount('Insurance', 'Claim Reporting') },
        { label: 'Offsystem Claims', path: '/admin/insurance/offsystem-claims', count: getSubModuleCount('Insurance', 'Offsystem Claims') },
        { label: 'Claims Required OTP', path: '/admin/insurance/claims-otp', count: getSubModuleCount('Insurance', 'Claims Required OTP') },
        { label: 'Sync Smart Benefits', path: '/admin/insurance/sync-benefits', count: getSubModuleCount('Insurance', 'Sync Smart Benefits') },
        { label: 'Template Claims', path: '/admin/insurance/template-claims', count: getSubModuleCount('Insurance', 'Template Claims') },
        { label: 'Member List', path: '/admin/insurance/member-list', count: getSubModuleCount('Insurance', 'Member List') },
        { label: 'Import Members', path: '/admin/insurance/import-members', count: getSubModuleCount('Insurance', 'Import Members') },
        { label: 'Insurance Drugs', path: '/admin/insurance/drugs', count: getSubModuleCount('Insurance', 'Insurance drugs') },
        { label: 'Preauth Drugs', path: '/admin/insurance/preauth-drugs', count: getSubModuleCount('Insurance', 'Preauth drugs') },
        { label: 'Ethical Substitute', path: '/admin/insurance/ethical-substitute', count: getSubModuleCount('Insurance', 'Ethical substitute') },
        { label: 'Import Benefit', path: '/admin/insurance/import-benefit', count: getSubModuleCount('Insurance', 'Import benefit') },
        { label: 'Import Ins Drugs', path: '/admin/insurance/import-ins-drugs', count: getSubModuleCount('Insurance', 'Import ins drugs') },
        { label: 'Prescriptions', path: '/admin/insurance/prescriptions', count: getSubModuleCount('Insurance', 'Prescriptions') },
        { label: 'Prepare Quotations', path: '/admin/insurance/prepare-quotations', count: getSubModuleCount('Insurance', 'Prepare Quotations') },
        { label: 'Orders on Delivery', path: '/admin/insurance/orders-delivery', count: getSubModuleCount('Insurance', 'Orders on Delivery') },
        { label: 'Refill Renewals', path: '/admin/insurance/refill-renewals', count: getSubModuleCount('Insurance', 'Refill Renewals') },
        { label: 'Link Smart-Actisure', path: '/admin/insurance/link-smart-actisure', count: getSubModuleCount('Insurance', 'Link Smart-Actisure Number') }
      ]
    },
    { icon: FileText, label: 'Jubilee Renewal Policy', path: '/admin/jubilee-renewal', count: getModuleCount('Jubilee Renewal Policy') },
    { icon: Shield, label: 'Insurance tracking', count: getModuleCount('Insurance tracking'), path: '/admin/insurance-tracking' },
    {
      icon: ClipboardList,
      label: 'Pre Auth',
      count: getModuleCount('Pre Auth'),
      subItems: [
        { label: 'Dental PreAuth', path: '/admin/preauth/dental', count: getSubModuleCount('Pre Auth', 'Dental PreAuth') },
        { label: 'InPatient PreAuth', path: '/admin/preauth/inpatient', count: getSubModuleCount('Pre Auth', 'InPatient PreAuth') },
        { label: 'OutPatient PreAuth', path: '/admin/preauth/outpatient', count: getSubModuleCount('Pre Auth', 'OutPatient PreAuth') },
        { label: 'Counselling PreAuth', path: '/admin/preauth/counselling', count: getSubModuleCount('Pre Auth', 'Counselling PreAuth') },
        { label: 'Physiotherapy PreAuth', path: '/admin/preauth/physiotherapy', count: getSubModuleCount('Pre Auth', 'Physiotherapy PreAuth') },
        { label: 'Lab PreAuth', path: '/admin/preauth/lab', count: getSubModuleCount('Pre Auth', 'Lab PreAuth') },
        { label: 'Imaging PreAuth', path: '/admin/preauth/imaging', count: getSubModuleCount('Pre Auth', 'Imaging PreAuth') },
        { label: 'Medicine PreAuth', path: '/admin/preauth/medicine', count: getSubModuleCount('Pre Auth', 'Medicine PreAuth') },
        { label: 'Optical PreAuth', path: '/admin/preauth/optical', count: getSubModuleCount('Pre Auth', 'Optical PreAuth') },
        { label: 'PreAuth Reapproval', path: '/admin/preauth/reapproval', count: getSubModuleCount('Pre Auth', 'PreAuth Reapproval') }
      ]
    },
    {
      icon: ShoppingCart,
      label: 'Orders',
      count: getModuleCount('Orders'),
      subItems: [
        { label: 'Total Orders', path: '/admin/orders/total', count: getSubModuleCount('Orders', 'Total Orders') },
        { label: 'In Process', path: '/admin/orders/in-process', count: getSubModuleCount('Orders', 'In Process') },
        { label: 'Best Offer', path: '/admin/orders/best-offer', count: getSubModuleCount('Orders', 'Best Offer') },
        { label: 'Prepare Order', path: '/admin/orders/prepare', count: getSubModuleCount('Orders', 'Prepare Order') },
        { label: 'On Delivery', path: '/admin/orders/on-delivery', count: getSubModuleCount('Orders', 'On Delivery') },
        { label: 'Not Received', path: '/admin/orders/not-received', count: getSubModuleCount('Orders', 'Not Received') },
        { label: 'In Payment', path: '/admin/orders/in-payment', count: getSubModuleCount('Orders', 'In Payment') },
        { label: 'Takeaway', path: '/admin/orders/takeaway', count: getSubModuleCount('Orders', 'Takeaway') },
        { label: 'On Moderation', path: '/admin/orders/moderation', count: getSubModuleCount('Orders', 'On Moderation') },
        { label: 'Alternative Items', path: '/admin/orders/alternative-items', count: getSubModuleCount('Orders', 'Alternative Items') },
        { label: 'Best Offer With Alternatives', path: '/admin/orders/best-offer-alt', count: getSubModuleCount('Orders', 'Best Offer With Alternatives') },
        { label: 'Prescription Need To Pay', path: '/admin/orders/prescription-pay', count: getSubModuleCount('Orders', 'Prescription Need To Pay') },
        { label: 'Prescription In Payment', path: '/admin/orders/prescription-payment', count: getSubModuleCount('Orders', 'Prescription In Payment') },
        { label: 'Pre Authorization', path: '/admin/orders/pre-authorization', count: getSubModuleCount('Orders', 'Pre Authorization') },
        { label: 'Prescription On Moderation', path: '/admin/orders/prescription-moderation', count: getSubModuleCount('Orders', 'Prescription On Moderation') }
      ]
    },
    {
      icon: Image,
      label: 'Transcribing photos',
      count: getModuleCount('Transcribing photos'),
      subItems: [
        { label: 'Prescription Photos', path: '/admin/transcribing/prescription-photos', count: getSubModuleCount('Transcribing photos', 'Prescription Photos') },
        { label: 'Prescription from Ins Panel', path: '/admin/transcribing/ins-panel', count: getSubModuleCount('Transcribing photos', 'Prescription from Ins Panel') }
      ]
    },
    {
      icon: Users,
      label: 'Users',
      count: getModuleCount('Users'),
      subItems: [
        { label: 'Super Admin', path: '/admin/users/super-admin', count: getSubModuleCount('Users', 'Super Admin') },
        { label: 'Administrators', path: '/admin/users/administrators', count: getSubModuleCount('Users', 'Administrators') },
        { label: 'Customer Care', path: '/admin/users/customer-care', count: getSubModuleCount('Users', 'Customer Care') },
        { label: 'Redactor', path: '/admin/users/redactor', count: getSubModuleCount('Users', 'Redactor') },
        { label: 'Pharmacy', path: '/admin/users/pharmacy', count: getSubModuleCount('Users', 'Pharmacy') },
        { label: 'Customers', path: '/admin/users/customers', count: getSubModuleCount('Users', 'Customers') },
        { label: 'Doctors', path: '/admin/users/doctors', count: getSubModuleCount('Users', 'Doctors') },
        { label: 'Insurer', path: '/admin/users/insurer', count: getSubModuleCount('Users', 'Insurer') },
        { label: 'Claim Specialist', path: '/admin/users/claim-specialist', count: getSubModuleCount('Users', 'Claim Specialist') },
        { label: 'Accountant', path: '/admin/users/accountant', count: getSubModuleCount('Users', 'Accountant') },
        { label: 'PBM Manager', path: '/admin/users/pbm-manager', count: getSubModuleCount('Users', 'PBM Manager') },
        { label: 'Brand Manufacturer', path: '/admin/users/brand-manufacturer', count: getSubModuleCount('Users', 'Brand Manufacturer') },
        { label: 'Pharmacist', path: '/admin/users/pharmacist', count: getSubModuleCount('Users', 'Pharmacist') },
        { label: 'Pre Auth Specialist', path: '/admin/users/preauth-specialist', count: getSubModuleCount('Users', 'Pre Auth Specialist') },
        { label: 'Provider Management', path: '/admin/users/provider-management', count: getSubModuleCount('Users', 'Provider Management') },
        { label: 'Labs', path: '/admin/users/labs', count: getSubModuleCount('Users', 'Labs') },
        { label: 'Optical Shop', path: '/admin/users/optical-shop', count: getSubModuleCount('Users', 'Optical Shop') },
        { label: 'Imagings', path: '/admin/users/imagings', count: getSubModuleCount('Users', 'Imagings') },
        { label: 'Provider Engagement', path: '/admin/users/provider-engagement', count: getSubModuleCount('Users', 'Provider Engagement') },
        { label: 'Notification Sender', path: '/admin/users/notification-sender', count: getSubModuleCount('Users', 'Notification Sender') }
      ]
    },
    { icon: CreditCard, label: 'Actisure Claim Payment Status', path: '/admin/actisure-payment' },
    {
      icon: Factory,
      label: 'Manufacturer',
      subItems: [
        { label: 'Drug Request Forms', path: '/admin/manufacturer/drug-requests' },
        { label: 'Block API to Manufacturer', path: '/admin/manufacturer/block-api' },
        { label: 'TP Update Requests', path: '/admin/manufacturer/tp-update' }
      ]
    },
    {
      icon: BarChart3,
      label: 'Analytics',
      subItems: [
        { label: 'Member History', path: '/admin/analytics/member-history' },
        { label: 'Doctor Analytics', path: '/admin/analytics/doctor' },
        { label: 'Member Analytics', path: '/admin/analytics/member' }
      ]
    },
    {
      icon: FileText,
      label: 'eTIMS',
      subItems: [
        { label: 'Code List', path: '/admin/etims/code-list' },
        { label: 'Classification List', path: '/admin/etims/classification' },
        { label: 'Notification List', path: '/admin/etims/notifications' }
      ]
    },
    { icon: Calendar, label: 'Appointments', path: '/admin/appointments' },
    { icon: Star, label: 'Appointment Ratings', path: '/admin/appointment-ratings' },
    { icon: CreditCard, label: 'Actisure Claim Payment Status', path: '/admin/actisure-payment', count: getModuleCount('Actisure Claim Payment Status') },
    {
      icon: Factory,
      label: 'Manufacturer',
      count: getModuleCount('Manufacturer'),
      subItems: [
        { label: 'Drug Request Forms', path: '/admin/manufacturer/drug-requests', count: getSubModuleCount('Manufacturer', 'Drug Request Forms') },
        { label: 'Block API to Manufacturer', path: '/admin/manufacturer/block-api', count: getSubModuleCount('Manufacturer', 'Block API to Manufacturer') },
        { label: 'TP Update Requests', path: '/admin/manufacturer/tp-update', count: getSubModuleCount('Manufacturer', 'TP Update Requests') }
      ]
    },
    {
      icon: BarChart3,
      label: 'Analytics',
      count: getModuleCount('Analytics'),
      subItems: [
        { label: 'Member History', path: '/admin/analytics/member-history', count: getSubModuleCount('Analytics', 'Member History') },
        { label: 'Doctor Analytics', path: '/admin/analytics/doctor', count: getSubModuleCount('Analytics', 'Doctor Analytics') },
        { label: 'Member Analytics', path: '/admin/analytics/member', count: getSubModuleCount('Analytics', 'Member Analytics') }
      ]
    },
    {
      icon: FileText,
      label: 'eTIMS',
      count: getModuleCount('eTIMS'),
      subItems: [
        { label: 'Code List', path: '/admin/etims/code-list', count: getSubModuleCount('eTIMS', 'Code List') },
        { label: 'Classification List', path: '/admin/etims/classification', count: getSubModuleCount('eTIMS', 'Classification List') },
        { label: 'Notification List', path: '/admin/etims/notifications', count: getSubModuleCount('eTIMS', 'Notification List') }
      ]
    },
    { icon: Calendar, label: 'Appointments', path: '/admin/appointments', count: getModuleCount('Appointments') },
    { icon: Star, label: 'Appointment Ratings', path: '/admin/appointment-ratings', count: getModuleCount('Appointment Ratings') },
    {
      icon: Package,
      label: 'Catalog',
      count: getModuleCount('Catalog'),
      subItems: [
        { label: 'Categories', path: '/admin/catalog/categories', count: getSubModuleCount('Catalog', 'Categories') },
        { label: 'Subcategories', path: '/admin/catalog/subcategories', count: getSubModuleCount('Catalog', 'Subcategories') },
        { label: 'Medicines', path: '/admin/catalog/medicines', count: getSubModuleCount('Catalog', 'Medicines') },
        { label: 'Manage Insurance Formulary', path: '/admin/catalog/insurance-formulary', count: getSubModuleCount('Catalog', 'Manage Insurance Formulary') },
        { label: 'Manage Regular Formulary', path: '/admin/catalog/regular-formulary', count: getSubModuleCount('Catalog', 'Manage Regular Formulary') },
        { label: 'Personal Items', path: '/admin/catalog/personal-items', count: getSubModuleCount('Catalog', 'Personal Items') },
        { label: 'Drug Index', path: '/admin/catalog/drug-index', count: getSubModuleCount('Catalog', 'Drug Index') },
        { label: 'Banners', path: '/admin/catalog/banners', count: getSubModuleCount('Catalog', 'Banners') }
      ]
    },
    {
      icon: ClipboardList,
      label: 'CDMP Program',
      count: getModuleCount('CDMP Program'),
      subItems: [
        { label: 'CDMP', path: '/admin/cdmp', count: getSubModuleCount('CDMP Program', 'CDMP') },
        { label: 'Upcoming Order', path: '/admin/cdmp/upcoming-orders', count: getSubModuleCount('CDMP Program', 'Upcoming Order') },
        { label: "Today's Order", path: '/admin/cdmp/today-orders', count: getSubModuleCount('CDMP Program', "Today's Order") },
        { label: 'Prepare Quotations', path: '/admin/cdmp/prepare-quotations', count: getSubModuleCount('CDMP Program', 'Prepare Quotations') },
        { label: 'Orders on Delivery', path: '/admin/cdmp/orders-delivery', count: getSubModuleCount('CDMP Program', 'Orders on Delivery') },
        { label: 'Refill Renewals', path: '/admin/cdmp/refill-renewals', count: getSubModuleCount('CDMP Program', 'Refill Renewals') },
        { label: 'Link Smart-Actisure', path: '/admin/cdmp/link-smart-actisure', count: getSubModuleCount('CDMP Program', 'Link Smart-Actisure Number') }
      ]
    },
    {
      icon: Truck,
      label: 'Delivery',
      count: getModuleCount('Delivery'),
      subItems: [
        { label: 'Delivery Man', path: '/admin/delivery/delivery-man', count: getSubModuleCount('Delivery', 'Delivery Man') },
        { label: 'Delivery Man on Map', path: '/admin/delivery/map', count: getSubModuleCount('Delivery', 'Delivery Man on Map') },
        { label: 'Active Orders', path: '/admin/delivery/active-orders', count: getSubModuleCount('Delivery', 'Active Orders') },
        { label: 'Cash Transfers', path: '/admin/delivery/cash-transfers', count: getSubModuleCount('Delivery', 'Cash Transfers') },
        { label: 'Rider Balance', path: '/admin/delivery/rider-balance', count: getSubModuleCount('Delivery', 'Rider Balance') }
      ]
    },
    {
      icon: Stethoscope,
      label: 'Doctors',
      count: getModuleCount('Doctors'),
      subItems: [
        { label: 'Doctors', path: '/admin/doctors/list', count: getSubModuleCount('Doctors', 'Doctors') },
        { label: 'Specialization', path: '/admin/doctors/specialization', count: getSubModuleCount('Doctors', 'Specialization') }
      ]
    },
    {
      icon: SearchIcon,
      label: 'Find OTP',
      count: getModuleCount('Find OTP'),
      subItems: [
        { label: 'Find Phone', path: '/admin/find-otp/phone', count: getSubModuleCount('Find OTP', 'Find Phone') },
        { label: 'Find Admin Section OTP', path: '/admin/find-otp/admin', count: getSubModuleCount('Find OTP', 'Find Admin Section OTP') }
      ]
    },
    { icon: FileText, label: 'FR Device Management', path: '/admin/fr-device', count: getModuleCount('FR Device Management') },
    { icon: Building2, label: 'Hospitals', path: '/admin/hospitals', count: getModuleCount('Hospitals') },
    {
      icon: FileText,
      label: 'Logs',
      count: getModuleCount('Logs'),
      subItems: [
        { label: 'SMS Log', path: '/admin/logs/sms', count: getSubModuleCount('Logs', 'SMS Log') },
        { label: 'Tutorial Logs', path: '/admin/logs/tutorial', count: getSubModuleCount('Logs', 'Tutorial Logs') }
      ]
    },
    {
      icon: CreditCard,
      label: 'M-pesa',
      count: getModuleCount('M-pesa'),
      subItems: [
        { label: 'M-Pesa Balance', path: '/admin/mpesa/balance', count: getSubModuleCount('M-pesa', 'M-Pesa Balance') }
      ]
    },
    {
      icon: Factory,
      label: 'Manufacturer Management',
      count: getModuleCount('Manufacturer Management'),
      subItems: [
        { label: 'Registration Request', path: '/admin/manufacturer-management/registration', count: getSubModuleCount('Manufacturer Management', 'Registration Request') },
        { label: 'Associate PPB Request', path: '/admin/manufacturer-management/ppb', count: getSubModuleCount('Manufacturer Management', 'Associate PPB Request') }
      ]
    },
    { icon: Building2, label: 'Provider Domain Management', path: '/admin/provider-domain', count: getModuleCount('Provider Domain Management') },
    {
      icon: FileText,
      label: 'Newsletter',
      count: getModuleCount('Newsletter'),
      subItems: [
        { label: 'Push and SMS', path: '/admin/newsletter/push-sms', count: getSubModuleCount('Newsletter', 'Push and SMS') }
      ]
    },
    {
      icon: FileText,
      label: 'Pages',
      count: getModuleCount('Pages'),
      subItems: [
        { label: 'Keys to Pages', path: '/admin/pages/keys', count: getSubModuleCount('Pages', 'Keys to Pages') },
        { label: 'Pages', path: '/admin/pages/list', count: getSubModuleCount('Pages', 'Pages') }
      ]
    },
    { icon: ShoppingCart, label: 'Pickup Orders', path: '/admin/pickup-orders', count: getModuleCount('Pickup Orders') },
    { icon: Building2, label: 'Pharmacy Branch Management', path: '/admin/pharmacy-branch', count: getModuleCount('Pharmacy Branch Management') },
    { icon: FileText, label: 'Pharmacy Device Management', path: '/admin/pharmacy-device', count: getModuleCount('Pharmacy Device Management') },
    { icon: Star, label: 'Ratings', path: '/admin/ratings', count: getModuleCount('Ratings') },
    { icon: CreditCard, label: 'Rebate Payment', path: '/admin/rebate-payment', count: getModuleCount('Rebate Payment') },
    { icon: FileText, label: 'Schemas', path: '/admin/schemas', count: getModuleCount('Schemas') },
    { icon: FileText, label: 'Send SMS', path: '/admin/send-sms', count: getModuleCount('Send SMS') },
    {
      icon: BarChart3,
      label: 'Statistics',
      count: getModuleCount('Statistics'),
      subItems: [
        { label: 'Pharmacy Payments', path: '/admin/statistics/pharmacy-payments', count: getSubModuleCount('Statistics', 'Pharmacy Payments') },
        { label: 'Pharmacy Balances', path: '/admin/statistics/pharmacy-balances', count: getSubModuleCount('Statistics', 'Pharmacy Balances') },
        { label: 'Doctor Payments', path: '/admin/statistics/doctor-payments', count: getSubModuleCount('Statistics', 'Doctor Payments') },
        { label: 'Doctor Balances', path: '/admin/statistics/doctor-balances', count: getSubModuleCount('Statistics', 'Doctor Balances') },
        { label: 'Appeal Payment List', path: '/admin/statistics/appeal-payments', count: getSubModuleCount('Statistics', 'Appeal Payment List') },
        { label: 'Partner Payment List', path: '/admin/statistics/partner-payments', count: getSubModuleCount('Statistics', 'Partner Payment List') },
        { label: 'Withholding Tax Payment List', path: '/admin/statistics/withholding-tax', count: getSubModuleCount('Statistics', 'Withholding Tax Payment List') },
        { label: 'Hospital Payments', path: '/admin/statistics/hospital-payments', count: getSubModuleCount('Statistics', 'Hospital Payments') },
        { label: 'Lab Payments', path: '/admin/statistics/lab-payments', count: getSubModuleCount('Statistics', 'Lab Payments') },
        { label: 'Imaging Payments', path: '/admin/statistics/imaging-payments', count: getSubModuleCount('Statistics', 'Imaging Payments') },
        { label: 'Optical Payments', path: '/admin/statistics/optical-payments', count: getSubModuleCount('Statistics', 'Optical Payments') },
        { label: 'Medicines', path: '/admin/statistics/medicines', count: getSubModuleCount('Statistics', 'Medicines') },
        { label: 'Medicine Rebate', path: '/admin/statistics/medicine-rebate', count: getSubModuleCount('Statistics', 'Medicine Rebate') }
      ]
    },
    {
      icon: FileText,
      label: 'Payment Log',
      count: getModuleCount('Payment Log'),
      subItems: [
        { label: 'Inbound', path: '/admin/payment-log/inbound', count: getSubModuleCount('Payment Log', 'Inbound') },
        { label: 'Outbound', path: '/admin/payment-log/outbound', count: getSubModuleCount('Payment Log', 'Outbound') }
      ]
    },
    { icon: Package, label: 'Top Selling Drug Management', path: '/admin/top-selling-drugs', count: getModuleCount('Top Selling Drug Management') },
    {
      icon: CreditCard,
      label: 'Transactions',
      count: getModuleCount('Transactions'),
      subItems: [
        { label: 'Transactions', path: '/admin/transactions', count: getSubModuleCount('Transactions', 'Transactions') },
        { label: 'List of Insurance Company Transactions', path: '/admin/transactions/insurance', count: getSubModuleCount('Transactions', 'List of Insurance Company Transactions') },
        { label: 'Mpesa Error Transactions', path: '/admin/transactions/mpesa-error', count: getSubModuleCount('Transactions', 'Mpesa Error Transactions') },
        { label: 'Mpesa Awaiting Transactions', path: '/admin/transactions/mpesa-awaiting', count: getSubModuleCount('Transactions', 'Mpesa Awaiting Transactions') }
      ]
    },
    { icon: Star, label: 'User Feedback', path: '/admin/user-feedback', count: getModuleCount('User Feedback') },
    {
      icon: Package,
      label: "I Don't see Medicine Order",
      count: getModuleCount("I Don't see Medicine Order"),
      subItems: [
        { label: 'Medicine Orders', path: '/admin/medicine-orders', count: getSubModuleCount("I Don't see Medicine Order", 'Medicine Orders') },
        { label: 'Statistics', path: '/admin/medicine-orders/statistics', count: getSubModuleCount("I Don't see Medicine Order", 'Statistics') }
      ]
    },
    {
      icon: FileText,
      label: 'CDMP Reporting',
      count: getModuleCount('CDMP Reporting'),
      subItems: [
        { label: 'Expired Programs', path: '/admin/cdmp-reporting/expired', count: getSubModuleCount('CDMP Reporting', 'Expired Programs') },
        { label: 'To be Expired in 7 Days', path: '/admin/cdmp-reporting/expiring', count: getSubModuleCount('CDMP Reporting', 'To be Expired in 7 Days') }
      ]
    },
    {
      icon: Users,
      label: 'VDPS',
      count: getModuleCount('VDPS'),
      subItems: [
        { label: 'Members', path: '/admin/vdps/members', count: getSubModuleCount('VDPS', 'Members') },
        { label: 'Requests', path: '/admin/vdps/requests', count: getSubModuleCount('VDPS', 'Requests') }
      ]
    },
    { icon: FileText, label: 'User Edit Log', path: '/admin/user-edit-log', count: getModuleCount('User Edit Log') },
    {
      icon: FileText,
      label: 'Subscriptions',
      count: getModuleCount('Subscriptions'),
      subItems: [
        { label: 'Subscription Plans', path: '/admin/subscriptions/plans', count: getSubModuleCount('Subscriptions', 'Subscription Plans') },
        { label: 'Current Subscription Assigned', path: '/admin/subscriptions/current', count: getSubModuleCount('Subscriptions', 'Current Subscription Assigned') },
        { label: 'Subscription Report/Invoice', path: '/admin/subscriptions/report', count: getSubModuleCount('Subscriptions', 'Subscription Report/Invoice') }
      ]
    },
    { icon: FileText, label: 'FAQ', path: '/admin/faq', count: getModuleCount('FAQ') },
    {
      icon: Settings,
      label: 'Settings',
      count: getModuleCount('Settings'),
      subItems: [
        { label: 'Globals', path: '/admin/settings/globals', count: getSubModuleCount('Settings', 'Globals') },
        { label: 'Subscription Setting', path: '/admin/settings/subscription', count: getSubModuleCount('Settings', 'Subscription Setting') },
        { label: 'Countries', path: '/admin/settings/countries', count: getSubModuleCount('Settings', 'Countries') },
        { label: 'Cities', path: '/admin/settings/cities', count: getSubModuleCount('Settings', 'Cities') },
        { label: 'Languages', path: '/admin/settings/languages', count: getSubModuleCount('Settings', 'Languages') },
        { label: 'Insurance Companies', path: '/admin/settings/insurance-companies', count: getSubModuleCount('Settings', 'Insurance Companies') },
        { label: 'Currencies', path: '/admin/settings/currencies', count: getSubModuleCount('Settings', 'Currencies') },
        { label: 'Excel Parsing', path: '/admin/settings/excel-parsing', count: getSubModuleCount('Settings', 'Excel Parsing') },
        { label: 'Offices', path: '/admin/settings/offices', count: getSubModuleCount('Settings', 'Offices') },
        { label: 'Partners', path: '/admin/settings/partners', count: getSubModuleCount('Settings', 'Partners') },
        { label: 'Application Versions', path: '/admin/settings/app-versions', count: getSubModuleCount('Settings', 'Application Versions') },
        { label: 'Manage Skip Provider GeoTag', path: '/admin/settings/geotag', count: getSubModuleCount('Settings', 'Manage Skip Provider GeoTag') }
      ]
    },
    {
      icon: Stethoscope,
      label: 'Dental Conditions',
      count: getModuleCount('Dental Conditions'),
      subItems: [
        { label: 'Full Mouth Procedures', path: '/admin/dental-conditions/full-mouth', count: getSubModuleCount('Dental Conditions', 'Full Mouth Procedures') },
        { label: 'Procedure', path: '/admin/dental-conditions/procedure', count: getSubModuleCount('Dental Conditions', 'Procedure') },
        { label: 'Time Duration Conditions', path: '/admin/dental-conditions/time-duration', count: getSubModuleCount('Dental Conditions', 'Time Duration Conditions') }
      ]
    }
  ];

  const toggleMenu = (label: string) => {
    setExpandedMenus((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(label)) {
        newSet.delete(label);
      } else {
        newSet.add(label);
      }
      return newSet;
    });
  };

  const isActive = (path?: string) => {
    if (!path) return false;
    if (path === '/admin') {
      return location.pathname === '/admin';
    }
    return location.pathname.startsWith(path);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors duration-300">
      {/* Top Header Bar */}
      <header className="navbar sticky top-0 z-50 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm">
        <div className="navbar-inner">
          <div className="flex items-center justify-between h-14 px-4">
            {/* Left Side */}
            <div className="flex items-center gap-4">
              {/* Sidebar Pusher (Mobile) */}
              <div className="sidebar-pusher lg:hidden">
                <button
                  onClick={() => setSidebarOpen(true)}
                  className="waves-effect waves-button waves-classic p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                  type="button"
                >
                  <Menu size={20} className="text-gray-700 dark:text-gray-300" />
                </button>
              </div>
              
              {/* Logo Box */}
              <div className="logo-box">
                <Link to="/admin" className="logo-text">
                  <span className="bg-teal-500 hover:bg-teal-600 text-white font-bold px-4 py-2 rounded transition-colors inline-block">
                    LIVIA
                  </span>
                </Link>
              </div>
            </div>

            {/* Right Side - Top Menu */}
            <div className="topmenu-outer">
              <div className="top-menu">
                <ul className="nav navbar-nav navbar-left hidden lg:flex items-center">
                  <li>
                    <button
                      onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                      className="waves-effect waves-button waves-classic sidebar-toggle p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                      type="button"
                      aria-label="Toggle sidebar"
                    >
                      <Menu size={20} className="text-gray-700 dark:text-gray-300" />
                    </button>
                  </li>
                </ul>
                
                <ul className="nav navbar-nav navbar-right flex items-center gap-1 flex-wrap">
                  {/* Language Dropdown */}
                  <li className="dropdown relative">
                    <button 
                      type="button"
                      className="dropdown-toggle waves-effect waves-button waves-classic flex items-center gap-2 px-2 sm:px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                    >
                      <img className="avatar w-5 h-5 sm:w-6 sm:h-6 rounded" src={currentLanguage.flag} alt={currentLanguage.name} />
                      <span className="user-name text-xs sm:text-sm text-gray-700 dark:text-gray-300 hidden sm:inline">{currentLanguage.nativeName}</span>
                      <ChevronDown size={14} className="text-gray-600 dark:text-gray-400 hidden sm:block" />
                    </button>
                    <ul className="dropdown-menu dropdown-list languges-list max-h-[400px] overflow-y-auto">
                      {languages.map((lang) => (
                        <li key={lang.code} role={lang.code}>
                          <button
                            type="button"
                            onClick={() => handleLanguageChange(lang.code)}
                            className={`w-full flex items-center gap-2 px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors ${
                              i18n.language === lang.code ? 'bg-gray-100 dark:bg-gray-700' : ''
                            }`}
                          >
                            <img src={lang.flag} alt={lang.name} className="w-6 h-6 rounded flex-shrink-0" />
                            <div className="flex flex-col items-start flex-1 min-w-0">
                              <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">{lang.nativeName}</span>
                              <span className="text-xs text-gray-500 dark:text-gray-400">{lang.name}</span>
                            </div>
                            {i18n.language === lang.code && (
                              <CheckCircle size={16} className="text-teal-600 dark:text-teal-400 flex-shrink-0" />
                            )}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </li>
                  
                  {/* Change Password */}
                  <li className="hidden md:block">
                    <Link
                      to="/admin/change-password"
                      target="_blank"
                      className="waves-effect waves-button waves-classic flex items-center gap-2 px-2 sm:px-3 py-2 text-xs sm:text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                    >
                      <Lock size={16} className="m-r-xs" />
                      <span className="hidden lg:inline">{t('common.changePassword')}</span>
                    </Link>
                  </li>
                  
                  {/* Blog Admin Management */}
                  <li className="hidden lg:block">
                    <Link
                      to="/admin/blog"
                      target="_blank"
                      className="log-out waves-effect waves-button waves-classic flex items-center gap-2 px-2 sm:px-3 py-2 text-xs sm:text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                    >
                      <FileText size={16} className="m-r-xs" />
                      <span>{t('common.blogAdmin')}</span>
                    </Link>
                  </li>
                  
                  {/* Log out */}
                  <li>
                    <button
                      type="button"
                      onClick={handleLogout}
                      className="log-out waves-effect waves-button waves-classic flex items-center gap-2 px-2 sm:px-3 py-2 text-xs sm:text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                    >
                      <LogOut size={16} className="m-r-xs" />
                      <span className="hidden sm:inline">{t('common.logout')}</span>
                    </button>
                  </li>
                  
                  {/* Theme Toggle */}
                  <li>
                    <ThemeToggle />
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`fixed top-14 left-0 z-40 h-[calc(100vh-3.5rem)] bg-[#212529] dark:bg-gray-900 transition-all duration-300 lg:translate-x-0 overflow-hidden flex flex-col ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } ${sidebarCollapsed ? 'w-20' : 'w-64'}`}
          style={{ maxWidth: sidebarCollapsed ? '5rem' : '16rem' }}
        >
          {/* Sidebar Profile Header */}
          <div className="sidebar-header border-b border-gray-700 relative">
            <div className="sidebar-profile p-4">
              <div className={`flex items-center ${sidebarCollapsed ? 'justify-center' : 'gap-3'}`}>
                <div className="sidebar-profile-image w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                  {user?.name?.charAt(0).toUpperCase() || 'A'}
                </div>
                {!sidebarCollapsed && (
                  <div className="sidebar-profile-details flex-1 min-w-0 flex items-center justify-between">
                    <span className="text-white text-sm font-medium block truncate">Admin Livia</span>
                    <button
                      onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                      className="p-1.5 hover:bg-gray-700 rounded transition-colors lg:block hidden flex-shrink-0"
                      title="Collapse sidebar"
                      type="button"
                    >
                      <ChevronLeft size={16} className="text-gray-300" />
                    </button>
                  </div>
                )}
              </div>
            </div>
            {sidebarCollapsed && (
              <button
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className="absolute top-4 right-2 p-1.5 hover:bg-gray-700 rounded transition-colors lg:block hidden z-10"
                title="Expand sidebar"
                type="button"
              >
                <ChevronRight size={16} className="text-gray-300" />
              </button>
            )}
          </div>

          {/* Navigation - Scrollable */}
          <nav className="flex-1 overflow-y-auto overflow-x-hidden py-2">
            <div className="space-y-0.5 w-full">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const hasSubItems = item.subItems && item.subItems.length > 0;
                const isExpanded = expandedMenus.has(item.label);
                const active = isActive(item.path);

                return (
                  <div key={item.label}>
                    {hasSubItems ? (
                      <>
                        <div className="relative group">
                          <button
                            onClick={() => !sidebarCollapsed && toggleMenu(item.label)}
                            className={`w-full flex items-center ${sidebarCollapsed ? 'justify-center' : 'justify-between'} px-4 py-2.5 transition-all duration-200 overflow-hidden ${
                              active || isExpanded
                                ? 'bg-gray-700 text-white'
                                : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                            }`}
                            title={sidebarCollapsed ? item.label : undefined}
                            type="button"
                          >
                          <div className={`flex items-center ${sidebarCollapsed ? '' : 'gap-3'} ${sidebarCollapsed ? 'justify-center' : ''}`}>
                            <Icon size={18} className="flex-shrink-0" />
                            {!sidebarCollapsed ? (
                              <span className="text-sm whitespace-nowrap overflow-hidden text-ellipsis">{item.label}</span>
                            ) : null}
                          </div>
                          {!sidebarCollapsed && (
                            <div className="flex items-center gap-2 flex-shrink-0">
                              {item.count !== undefined && item.count > 0 && (
                                <span className="text-xs bg-teal-600 text-white px-2 py-0.5 rounded-full font-semibold">{item.count}</span>
                              )}
                              {isExpanded ? (
                                <ChevronDown size={14} className="flex-shrink-0" />
                              ) : (
                                <ChevronRight size={14} className="flex-shrink-0" />
                              )}
                            </div>
                          )}
                        </button>
                        {sidebarCollapsed && (
                          <div className="absolute left-full ml-2 bg-gray-800 rounded-lg shadow-xl py-2 min-w-[200px] z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                            <div className="px-4 py-2 text-white font-semibold border-b border-gray-700">
                              {item.label}
                            </div>
                            {item.subItems && item.subItems.map((subItem) => {
                              const SubIcon = subItem.icon || getSubModuleIcon(item.label, subItem.label);
                              const subActive = location.pathname === subItem.path;
                              return (
                                <Link
                                  key={subItem.path}
                                  to={subItem.path}
                                  onClick={() => setSidebarOpen(false)}
                                  className={`flex items-center justify-between px-4 py-2 text-sm transition-all duration-200 ${
                                    subActive
                                      ? 'bg-gray-700 text-white'
                                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                                  }`}
                                  title={subItem.label}
                                >
                                  <div className="flex items-center gap-2">
                                    <SubIcon size={14} className="flex-shrink-0" />
                                    <span>{subItem.label}</span>
                                  </div>
                                  {subItem.count !== undefined && subItem.count > 0 && (
                                    <span className="text-xs bg-teal-600 text-white px-2 py-0.5 rounded-full font-semibold">{subItem.count}</span>
                                  )}
                                </Link>
                              );
                            })}
                          </div>
                        )}
                        </div>
                        {isExpanded && !sidebarCollapsed && (
                          <div className="bg-gray-800/50">
                            {item.subItems!.map((subItem) => {
                              const subActive = location.pathname === subItem.path;
                              const SubIcon = subItem.icon || getSubModuleIcon(item.label, subItem.label);
                              return (
                                <Link
                                  key={subItem.path}
                                  to={subItem.path}
                                  onClick={() => setSidebarOpen(false)}
                                  className={`flex items-center justify-between px-4 py-2 text-sm transition-all duration-200 ${
                                    subActive
                                      ? 'bg-gray-700 text-white'
                                      : 'text-gray-400 hover:bg-gray-800 hover:text-gray-300'
                                  }`}
                                  title={subItem.label}
                                >
                                  <div className="flex items-center gap-2">
                                    <SubIcon size={16} className="flex-shrink-0" />
                                    <span>{subItem.label}</span>
                                  </div>
                                  {subItem.count !== undefined && subItem.count > 0 && (
                                    <span className="text-xs bg-teal-600 text-white px-2 py-0.5 rounded-full font-semibold">{subItem.count}</span>
                                  )}
                                </Link>
                              );
                            })}
                          </div>
                        )}
                        {isExpanded && sidebarCollapsed && (
                          <div className="absolute left-full ml-2 bg-gray-800 rounded-lg shadow-xl py-2 min-w-[200px] z-50">
                            {item.subItems!.map((subItem) => {
                              const subActive = location.pathname === subItem.path;
                              const SubIcon = subItem.icon || getSubModuleIcon(item.label, subItem.label);
                              return (
                                <Link
                                  key={subItem.path}
                                  to={subItem.path}
                                  onClick={() => setSidebarOpen(false)}
                                  className={`flex items-center gap-2 px-4 py-2 text-sm transition-all duration-200 ${
                                    subActive
                                      ? 'bg-gray-700 text-white'
                                      : 'text-gray-400 hover:bg-gray-700 hover:text-white'
                                  }`}
                                  title={subItem.label}
                                >
                                  <SubIcon size={16} className="flex-shrink-0" />
                                  <span>{subItem.label}</span>
                                  {subItem.count !== undefined && subItem.count > 0 && (
                                    <span className="ml-auto text-xs bg-teal-600 text-white px-2 py-0.5 rounded-full font-semibold">{subItem.count}</span>
                                  )}
                                </Link>
                              );
                            })}
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="relative group">
                        <Link
                          to={item.path!}
                          onClick={() => setSidebarOpen(false)}
                          className={`flex items-center ${sidebarCollapsed ? 'justify-center' : 'justify-between'} px-4 py-2.5 transition-all duration-200 overflow-hidden ${
                            active
                              ? 'bg-gray-700 text-white'
                              : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                          }`}
                          title={sidebarCollapsed ? item.label : undefined}
                        >
                        <div className={`flex items-center ${sidebarCollapsed ? '' : 'gap-3'} ${sidebarCollapsed ? 'justify-center' : ''} ${sidebarCollapsed ? 'w-full' : ''}`}>
                          <Icon size={18} className="flex-shrink-0" />
                          {!sidebarCollapsed ? (
                            <span className="text-sm whitespace-nowrap overflow-hidden text-ellipsis">{item.label}</span>
                          ) : null}
                        </div>
                        {!sidebarCollapsed && item.count !== undefined && item.count > 0 && (
                          <span className="text-xs bg-teal-600 text-white px-2 py-0.5 rounded-full font-semibold flex-shrink-0">{item.count}</span>
                        )}
                      </Link>
                      {sidebarCollapsed && (
                        <div className="absolute left-full ml-2 bg-gray-800 rounded-lg shadow-xl px-3 py-2 z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 whitespace-nowrap">
                          <span className="text-sm text-white">{item.label}</span>
                        </div>
                      )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </nav>
        </aside>

        {/* Main Content */}
        <div className={`flex-1 transition-all duration-300 ${sidebarCollapsed ? 'lg:ml-20' : 'lg:ml-64'}`}>
          <main className="p-6">{children}</main>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden top-14"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
};

export default AdminLayout;