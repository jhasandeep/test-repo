import React from 'react';
import { Truck, ShieldCheck, Clock } from 'lucide-react';

const Features = () => {
  return (
    <section className="py-16 border-y border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-gray-800/50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex items-center gap-4 p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100 dark:border-gray-700">
            <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Truck size={24} />
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white transition-colors duration-300">Free Shipping</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 transition-colors duration-300">On all orders over $150</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100 dark:border-gray-700">
            <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/50 rounded-full flex items-center justify-center text-rose-600 dark:text-rose-400">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white transition-colors duration-300">Warranty</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 transition-colors duration-300">30-day money back guarantee</p>
            </div>
          </div>
          <div className="flex items-center gap-4 p-6 bg-white dark:bg-gray-800 rounded-xl shadow-sm hover:shadow-md transition-all border border-gray-100 dark:border-gray-700">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center text-blue-600 dark:text-blue-400">
              <Clock size={24} />
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white transition-colors duration-300">Support 24/7</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 transition-colors duration-300">Online support 24 hours a day</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;