import React, { useState } from 'react';
import { Heart, ShoppingBag, Star } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

interface ProductCardProps {
  id: number;
  title: string;
  type: string;
  price: string;
  img: string;
  badge: string;
  onCartOpen?: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({
  id,
  title,
  type,
  price,
  img,
  badge,
  onCartOpen
}) => {
  const { addToCart } = useCart();
  const [isWishlisted, setIsWishlisted] = useState(false);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    addToCart({
      id,
      name: title,
      description: `${type} - ${title}`,
      price: parseFloat(price),
      emoji: '👟',
      image: img
    });

    // Open cart sidebar after adding
    if (onCartOpen) {
      onCartOpen();
    }
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlisted(!isWishlisted);
  };

  return (
    <div className="group relative bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 ease-out border border-gray-100 dark:border-gray-700 flex flex-col h-full">
      {/* Badge */}
      {badge && (
        <div className="absolute top-4 left-4 z-10 bg-black dark:bg-gray-900 text-white dark:text-gray-100 text-xs font-bold px-3 py-1 uppercase tracking-wider rounded-sm">
          {badge}
        </div>
      )}

      {/* Wishlist Button */}
      <button
        onClick={handleToggleWishlist}
        className={`absolute top-4 right-4 z-10 w-8 h-8 rounded-full backdrop-blur flex items-center justify-center transition-all duration-300 shadow-sm ${
          isWishlisted
            ? 'bg-rose-500 dark:bg-rose-600 text-white opacity-100'
            : 'bg-white/80 dark:bg-gray-800/80 text-gray-400 dark:text-gray-500 hover:text-rose-500 dark:hover:text-rose-400 hover:bg-white dark:hover:bg-gray-700 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0'
        }`}
      >
        <Heart size={16} fill={isWishlisted ? 'currentColor' : 'none'} />
      </button>

      {/* Image Container */}
      <div className="relative h-72 bg-gray-50 dark:bg-gray-900 overflow-hidden">
        <div className="absolute inset-0 bg-indigo-600/5 dark:bg-indigo-500/10 group-hover:bg-indigo-600/10 dark:group-hover:bg-indigo-500/20 transition-colors duration-500"></div>
        <img
          src={img}
          alt={title}
          className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-700"
        />

        {/* Quick Add Button */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-[90%]">
          <button
            onClick={handleQuickAdd}
            className="w-full bg-white dark:bg-gray-800 text-black dark:text-white py-3 rounded-lg font-bold text-sm shadow-lg transform translate-y-[120%] group-hover:translate-y-0 transition-transform duration-300 flex items-center justify-center gap-2 hover:bg-indigo-600 dark:hover:bg-indigo-500 hover:text-white active:scale-95 cursor-pointer border border-gray-200 dark:border-gray-700"
          >
            <ShoppingBag size={16} /> Quick Add
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="p-5 flex-1 flex flex-col justify-end">
        <div className="text-xs text-gray-500 dark:text-gray-400 font-bold uppercase tracking-wider mb-1">
          {type}
        </div>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors cursor-pointer">
          {title}
        </h3>
        <div className="flex justify-between items-end mt-auto">
          <div className="flex items-center gap-1 mb-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star key={s} size={12} className="text-yellow-400 dark:text-yellow-500 fill-current" />
            ))}
            <span className="text-xs text-gray-400 dark:text-gray-500 ml-1">(42)</span>
          </div>
          <div className="text-xl font-black text-gray-900 dark:text-white transition-colors duration-300">${price}</div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;