import React from 'react';
import { ArrowRight } from 'lucide-react';
import ProductCard from './ProductCard';

interface ProductsSectionProps {
  onCartOpen?: () => void;
}

const ProductsSection: React.FC<ProductsSectionProps> = ({ onCartOpen }) => {
  const products = [
    {
      id: 1,
      title: 'Stride Vapor Fly',
      type: 'Marathon Racing',
      price: '210.00',
      img: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?q=80&w=1000&auto=format&fit=crop',
      badge: 'New'
    },
    {
      id: 2,
      title: 'Stride Pegasus 40',
      type: 'Daily Training',
      price: '145.00',
      img: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?q=80&w=1000&auto=format&fit=crop',
      badge: 'Best Seller'
    },
    {
      id: 3,
      title: 'Trail Gtx Ultra',
      type: 'Trail Running',
      price: '180.00',
      img: 'https://images.unsplash.com/photo-1584735175097-719d848f8449?q=80&w=1000&auto=format&fit=crop',
      badge: ''
    },
    {
      id: 4,
      title: 'Sprint Elite 2',
      type: 'Track & Field',
      price: '130.00',
      img: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=1000&auto=format&fit=crop',
      badge: 'Sale'
    }
  ];

  return (
    <section id="shop" className="py-20 bg-white dark:bg-gray-900 scroll-mt-20 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-4">
          <div>
            <h2 className="text-4xl font-black text-gray-900 dark:text-white mb-3 transition-colors duration-300">
              Trending Now
            </h2>
            <p className="text-gray-500 dark:text-gray-400 max-w-md transition-colors duration-300">
              Our latest technology meets street-ready aesthetics. Discover what the pros are wearing this season.
            </p>
          </div>
          <a
            href="#"
            className="group flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold hover:text-indigo-800 dark:hover:text-indigo-300 transition-colors duration-200"
          >
            View All Products{' '}
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} {...product} onCartOpen={onCartOpen} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;