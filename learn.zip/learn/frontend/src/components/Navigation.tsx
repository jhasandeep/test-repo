import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingBag, Search, User } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import ThemeToggle from './ThemeToggle';

interface NavigationProps {
  onCartClick?: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ onCartClick }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { getTotalItems } = useCart();
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();
  const cartCount = getTotalItems();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsOpen(false);
  };

  const handleCartClick = () => {
    if (onCartClick) {
      onCartClick();
    } else {
      navigate('/cart');
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 dark:bg-gray-900/90 backdrop-blur-lg shadow-md py-4'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-1 group cursor-pointer"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            <div className="w-8 h-8 bg-indigo-600 dark:bg-indigo-500 rounded-br-xl rounded-tl-xl flex items-center justify-center group-hover:rotate-12 transition-transform">
              <span className="text-white font-bold text-lg italic">S</span>
            </div>
            <span
              className={`text-2xl font-black tracking-tighter italic ${
                scrolled
                  ? 'text-gray-900 dark:text-white'
                  : 'text-gray-900 dark:text-white lg:text-white'
              }`}
            >
              STRIDE
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection('shop')}
              className={`text-sm font-bold uppercase tracking-wide transition-colors hover:text-indigo-500 dark:hover:text-indigo-400 ${
                scrolled
                  ? 'text-gray-700 dark:text-gray-300'
                  : 'text-gray-700 dark:text-gray-300'
              }`}
            >
              New Drops
            </button>
            <button
              onClick={() => scrollToSection('shop')}
              className={`text-sm font-bold uppercase tracking-wide transition-colors hover:text-indigo-500 dark:hover:text-indigo-400 ${
                scrolled
                  ? 'text-gray-700 dark:text-gray-300'
                  : 'text-gray-700 dark:text-gray-300'
              }`}
            >
              Men
            </button>
            <button
              onClick={() => scrollToSection('shop')}
              className={`text-sm font-bold uppercase tracking-wide transition-colors hover:text-indigo-500 dark:hover:text-indigo-400 ${
                scrolled
                  ? 'text-gray-700 dark:text-gray-300'
                  : 'text-gray-700 dark:text-gray-300'
              }`}
            >
              Women
            </button>
            <button
              onClick={() => scrollToSection('shop')}
              className="text-sm font-bold uppercase tracking-wide transition-colors hover:text-rose-600 dark:hover:text-rose-400 text-rose-500 dark:text-rose-400"
            >
              Sale
            </button>
          </div>

          {/* Icons */}
          <div className="hidden md:flex items-center space-x-4">
            <ThemeToggle />
            <button
              className={`w-5 h-5 cursor-pointer hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors ${
                scrolled
                  ? 'text-gray-700 dark:text-gray-300'
                  : 'text-gray-700 dark:text-gray-300'
              }`}
            >
              <Search className="w-5 h-5" />
            </button>
            {isAuthenticated ? (
              <Link
                to="/profile"
                className={`w-5 h-5 cursor-pointer hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors ${
                  scrolled
                    ? 'text-gray-700 dark:text-gray-300'
                    : 'text-gray-700 dark:text-gray-300'
                }`}
              >
                <User className="w-5 h-5" />
              </Link>
            ) : (
              <Link
                to="/login"
                className={`w-5 h-5 cursor-pointer hover:text-indigo-500 dark:hover:text-indigo-400 transition-colors ${
                  scrolled
                    ? 'text-gray-700 dark:text-gray-300'
                    : 'text-gray-700 dark:text-gray-300'
                }`}
              >
                <User className="w-5 h-5" />
              </Link>
            )}
            <button onClick={handleCartClick} className="relative cursor-pointer group">
              <ShoppingBag
                className={`w-5 h-5 group-hover:text-indigo-500 dark:group-hover:text-indigo-400 transition-colors ${
                  scrolled
                    ? 'text-gray-700 dark:text-gray-300'
                    : 'text-gray-700 dark:text-gray-300'
                }`}
              />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-indigo-600 dark:bg-indigo-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-scale-in">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden flex items-center gap-4">
            <ThemeToggle />
            <button onClick={handleCartClick} className="relative cursor-pointer">
              <ShoppingBag className="w-6 h-6 text-gray-900 dark:text-white" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-indigo-600 dark:bg-indigo-500 text-white text-[9px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-900 dark:text-white"
            >
              {isOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden absolute top-full left-0 w-full bg-white dark:bg-gray-900 shadow-xl transition-all duration-300 ease-in-out overflow-hidden border-t border-gray-100 dark:border-gray-800 ${
          isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="px-4 py-6 space-y-4 flex flex-col">
          <button
            onClick={() => scrollToSection('shop')}
            className="text-left text-lg font-bold border-b border-gray-100 dark:border-gray-800 pb-2 text-gray-800 dark:text-gray-200"
          >
            New Drops
          </button>
          <button
            onClick={() => scrollToSection('shop')}
            className="text-left text-lg font-bold border-b border-gray-100 dark:border-gray-800 pb-2 text-gray-800 dark:text-gray-200"
          >
            Men
          </button>
          <button
            onClick={() => scrollToSection('shop')}
            className="text-left text-lg font-bold border-b border-gray-100 dark:border-gray-800 pb-2 text-gray-800 dark:text-gray-200"
          >
            Women
          </button>
          <button
            onClick={() => scrollToSection('shop')}
            className="text-left text-lg font-bold border-b border-gray-100 dark:border-gray-800 pb-2 text-rose-500 dark:text-rose-400"
          >
            Sale
          </button>
          <div className="flex gap-4 pt-4">
            {isAuthenticated ? (
              <>
                <Link
                  to="/profile"
                  className="flex-1 bg-gray-100 dark:bg-gray-800 py-3 rounded-lg flex justify-center items-center gap-2 text-gray-700 dark:text-gray-300 font-medium"
                  onClick={() => setIsOpen(false)}
                >
                  <User size={18} /> {user?.name || 'Account'}
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex-1 bg-rose-500 dark:bg-rose-600 py-3 rounded-lg flex justify-center items-center gap-2 text-white font-medium"
                >
                  Logout
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="flex-1 bg-indigo-600 dark:bg-indigo-500 py-3 rounded-lg flex justify-center items-center gap-2 text-white font-medium"
                onClick={() => setIsOpen(false)}
              >
                <User size={18} /> Login
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;