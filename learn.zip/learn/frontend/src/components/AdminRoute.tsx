import React from 'react';
import ProtectedRoute from './ProtectedRoute';
import AdminLayout from './admin/AdminLayout';

interface AdminRouteProps {
  children: React.ReactNode;
}

const AdminRoute: React.FC<AdminRouteProps> = ({ children }) => {
  return (
    <ProtectedRoute>
      <AdminLayout>
        {children}
      </AdminLayout>
    </ProtectedRoute>
  );
};

export default AdminRoute;



