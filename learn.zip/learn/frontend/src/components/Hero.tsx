import React from 'react';
import { Star, ArrowRight } from 'lucide-react';

interface HeroProps {
  onShopClick?: () => void;
}

const Hero: React.FC<HeroProps> = ({ onShopClick }) => {
  return (
    <div className="relative min-h-screen bg-white dark:bg-gray-900 flex items-center overflow-hidden transition-colors duration-300">
      {/* Abstract Background Shapes */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-indigo-200/40 dark:bg-indigo-900/30 blur-[120px]"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-rose-200/40 dark:bg-rose-900/30 blur-[100px]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 pt-20 pb-10 md:pt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="text-center md:text-left space-y-8 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-50 dark:bg-indigo-900/50 border border-indigo-100 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 text-sm font-semibold shadow-sm">
              <Star size={14} fill="currentColor" /> #1 Rated Running Shoe 2025
            </div>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 dark:text-white leading-tight tracking-tight transition-colors duration-300">
              RUN <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-rose-500 dark:from-indigo-400 dark:to-rose-400">BEYOND</span> <br />
              <span className="italic text-slate-400 dark:text-gray-500">LIMITS.</span>
            </h1>
            <p className="text-gray-600 dark:text-gray-300 text-lg max-w-lg mx-auto md:mx-0 leading-relaxed transition-colors duration-300">
              Engineered with AeroFoam™ technology. The new Stride Velocity X provides 40% more energy return with every step you take.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <button
                onClick={onShopClick}
                className="px-8 py-4 bg-indigo-600 dark:bg-indigo-500 hover:bg-indigo-700 dark:hover:bg-indigo-600 text-white rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg shadow-indigo-600/30 dark:shadow-indigo-500/30 flex items-center justify-center gap-2"
              >
                Shop Collection <ArrowRight size={20} />
              </button>
              <button className="px-8 py-4 bg-transparent border border-gray-300 dark:border-gray-700 hover:border-indigo-600 dark:hover:border-indigo-500 text-slate-700 dark:text-gray-300 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg font-bold text-lg transition-all hover:bg-indigo-50 dark:hover:bg-indigo-900/30">
                View Technology
              </button>
            </div>

            {/* Stats */}
            <div className="flex justify-center md:justify-start gap-8 pt-8 border-t border-gray-200 dark:border-gray-800">
              <div>
                <p className="text-3xl font-black text-slate-900 dark:text-white transition-colors duration-300">210g</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider">Weight</p>
              </div>
              <div>
                <p className="text-3xl font-black text-slate-900 dark:text-white transition-colors duration-300">42mm</p>
                <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider">Stack Height</p>
              </div>
            </div>
          </div>

          {/* Image/Visual */}
          <div className="relative h-[400px] md:h-[600px] flex items-center justify-center group perspective-1000">
            {/* Circle Graphic behind shoe */}
            <div className="absolute w-[300px] h-[300px] md:w-[500px] md:h-[500px] border border-slate-200 dark:border-gray-800 rounded-full animate-[spin_20s_linear_infinite]"></div>
            <div className="absolute w-[250px] h-[250px] md:w-[400px] md:h-[400px] border border-dashed border-indigo-500/30 dark:border-indigo-500/20 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>

            {/* Shoe Image */}
            <img
              src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1000&auto=format&fit=crop"
              alt="Stride Velocity X"
              className="relative z-10 w-full max-w-md drop-shadow-[0_35px_35px_rgba(0,0,0,0.25)] dark:drop-shadow-[0_35px_35px_rgba(0,0,0,0.5)] transform rotate-[-15deg] transition-transform duration-500 group-hover:rotate-[-5deg] group-hover:scale-110"
            />

            {/* Floating Badge */}
            <div className="absolute top-[20%] right-[10%] bg-white/90 dark:bg-gray-800/90 backdrop-blur-md border border-slate-100 dark:border-gray-700 shadow-2xl p-4 rounded-2xl z-20 animate-bounce-slow hidden md:block">
              <div className="text-xs text-gray-500 dark:text-gray-400 uppercase font-bold">Energy Return</div>
              <div className="text-2xl font-bold text-rose-500 dark:text-rose-400">+40%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;