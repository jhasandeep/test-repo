// Configuration for module fields
export const moduleFieldMap: Record<string, string[]> = {
  'Analytics': ['reportId', 'type', 'date', 'status', 'value'],
  'eTIMS': ['code', 'name', 'category', 'status', 'date'],
  'Appointments': ['appointmentId', 'patientName', 'doctorName', 'date', 'status'],
  'Appointment Ratings': ['ratingId', 'appointmentId', 'rating', 'comment', 'date'],
  'Catalog': ['productId', 'name', 'category', 'price', 'status'],
  'CDMP Program': ['programId', 'memberName', 'type', 'status', 'date'],
  'Delivery': ['deliveryId', 'orderId', 'riderName', 'status', 'date'],
  'Doctors': ['doctorId', 'name', 'specialization', 'email', 'status'],
  'Find OTP': ['otpId', 'phone', 'otp', 'status', 'date'],
  'FR Device Management': ['deviceId', 'name', 'location', 'status', 'lastSync'],
  'Hospitals': ['hospitalId', 'name', 'location', 'status', 'date'],
  'Logs': ['logId', 'type', 'message', 'date', 'status'],
  'M-pesa': ['transactionId', 'phone', 'amount', 'status', 'date'],
  'Manufacturer Management': ['requestId', 'manufacturerName', 'status', 'date', 'contact'],
  'Provider Domain Management': ['domainId', 'domain', 'provider', 'status', 'date'],
  'Newsletter': ['newsletterId', 'title', 'type', 'status', 'date'],
  'Pages': ['pageId', 'title', 'key', 'status', 'date'],
  'Pickup Orders': ['orderId', 'customerName', 'pickupLocation', 'status', 'date'],
  'Pharmacy Branch Management': ['branchId', 'name', 'location', 'status', 'date'],
  'Pharmacy Device Management': ['deviceId', 'name', 'pharmacy', 'status', 'lastSync'],
  'Ratings': ['ratingId', 'itemName', 'rating', 'comment', 'date'],
  'Rebate Payment': ['paymentId', 'recipient', 'amount', 'status', 'date'],
  'Schemas': ['schemaId', 'name', 'version', 'status', 'date'],
  'Send SMS': ['smsId', 'recipient', 'message', 'status', 'date'],
  'Statistics': ['statId', 'category', 'value', 'period', 'date'],
  'Payment Log': ['logId', 'transactionId', 'type', 'amount', 'date'],
  'Top Selling Drug Management': ['drugId', 'name', 'sales', 'revenue', 'period'],
  'Transactions': ['transactionId', 'type', 'amount', 'status', 'date'],
  'User Feedback': ['feedbackId', 'userName', 'category', 'rating', 'date'],
  "I Don't see Medicine Order": ['orderId', 'patientName', 'medicine', 'status', 'date'],
  'CDMP Reporting': ['reportId', 'programId', 'type', 'status', 'date'],
  'VDPS': ['memberId', 'name', 'type', 'status', 'date'],
  'User Edit Log': ['logId', 'userId', 'action', 'field', 'date'],
  'Subscriptions': ['subscriptionId', 'planName', 'userName', 'status', 'expiryDate'],
  'FAQ': ['faqId', 'question', 'category', 'status', 'date'],
  'Settings': ['settingId', 'key', 'value', 'category', 'date'],
  'Dental Conditions': ['conditionId', 'name', 'type', 'status', 'date']
};

export const getModuleFields = (title: string): string[] => {
  return moduleFieldMap[title] || ['id', 'name', 'status', 'date', 'type'];
};


