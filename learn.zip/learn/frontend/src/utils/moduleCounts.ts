// Notification counts for each module
export const moduleCounts: Record<string, number> = {
  'Dashboard': 0,
  'Business Hospitals': 1,
  'Insurance': 295,
  'Jubilee Renewal Policy': 0,
  'Insurance tracking': 166,
  'Pre Auth': 1798,
  'Orders': 7130,
  'Transcribing photos': 1185,
  'Users': 0,
  'Actisure Claim Payment Status': 0,
  'Manufacturer': 0,
  'Analytics': 0,
  'eTIMS': 0,
  'Appointments': 0,
  'Appointment Ratings': 0,
  'Catalog': 0,
  'CDMP Program': 0,
  'Delivery': 0,
  'Doctors': 0,
  'Find OTP': 0,
  'FR Device Management': 0,
  'Hospitals': 0,
  'Logs': 0,
  'M-pesa': 0,
  'Manufacturer Management': 0,
  'Provider Domain Management': 0,
  'Newsletter': 0,
  'Pages': 0,
  'Pickup Orders': 0,
  'Pharmacy Branch Management': 0,
  'Pharmacy Device Management': 0,
  'Ratings': 0,
  'Rebate Payment': 0,
  'Schemas': 0,
  'Send SMS': 0,
  'Statistics': 0,
  'Payment Log': 0,
  'Top Selling Drug Management': 0,
  'Transactions': 0,
  'User Feedback': 0,
  "I Don't see Medicine Order": 0,
  'CDMP Reporting': 0,
  'VDPS': 0,
  'User Edit Log': 0,
  'Subscriptions': 0,
  'FAQ': 0,
  'Settings': 0,
  'Dental Conditions': 0
};

// Sub-module counts
export const subModuleCounts: Record<string, Record<string, number>> = {
  'Business Hospitals': {
    'Branches': 0,
    'Requests': 1,
    'Declined': 0,
    'Hospital Users': 0
  },
  'Insurance': {
    'E-claims': 45,
    'Claim Reporting': 12,
    'Offsystem Claims': 8,
    'Claims Required OTP': 23,
    'Sync Smart Benefits': 5,
    'Template Claims': 0,
    'Member List': 295,
    'Import Members': 0,
    'Insurance drugs': 156,
    'Preauth drugs': 89,
    'Ethical substitute': 34,
    'Import benefit': 0,
    'Import ins drugs': 0,
    'Prescriptions': 234,
    'Prepare Quotations': 67,
    'Orders on Delivery': 123,
    'Refill Renewals': 45,
    'Link Smart-Actisure Number': 0
  },
  'Pre Auth': {
    'Dental PreAuth': 234,
    'InPatient PreAuth': 567,
    'OutPatient PreAuth': 456,
    'Counselling PreAuth': 123,
    'Physiotherapy PreAuth': 89,
    'Lab PreAuth': 234,
    'Imaging PreAuth': 156,
    'Medicine PreAuth': 345,
    'Optical PreAuth': 90,
    'PreAuth Reapproval': 0
  },
  'Orders': {
    'Total Orders': 7130,
    'In Process': 1234,
    'Best Offer': 567,
    'Prepare Order': 234,
    'On Delivery': 456,
    'Not Received': 89,
    'In Payment': 345,
    'Takeaway': 123,
    'On Moderation': 234,
    'Alternative Items': 156,
    'Best Offer With Alternatives': 67,
    'Prescription Need To Pay': 234,
    'Prescription In Payment': 123,
    'Pre Authorization': 456,
    'Prescription On Moderation': 89
  },
  'Transcribing photos': {
    'Prescription Photos': 987,
    'Prescription from Ins Panel': 198
  },
  'Users': {
    'Super Admin': 5,
    'Administrators': 23,
    'Customer Care': 45,
    'Redactor': 12,
    'Pharmacy': 234,
    'Customers': 5678,
    'Doctors': 456,
    'Insurer': 34,
    'Claim Specialist': 67,
    'Accountant': 23,
    'PBM Manager': 12,
    'Brand Manufacturer': 45,
    'Pharmacist': 234,
    'Pre Auth Specialist': 89,
    'Provider Management': 34,
    'Labs': 123,
    'Optical Shop': 56,
    'Imagings': 78,
    'Provider Engagement': 23,
    'Notification Sender': 12
  },
  'Manufacturer': {
    'Drug Request Forms': 45,
    'Block API to Manufacturer': 0,
    'TP Update Requests': 12
  },
  'Analytics': {
    'Member History': 0,
    'Doctor Analytics': 0,
    'Member Analytics': 0
  },
  'eTIMS': {
    'Code List': 0,
    'Classification List': 0,
    'Notification List': 0
  },
  'Catalog': {
    'Categories': 0,
    'Subcategories': 0,
    'Medicines': 0,
    'Manage Insurance Formulary': 0,
    'Manage Regular Formulary': 0,
    'Personal Items': 0,
    'Drug Index': 0,
    'Banners': 0
  },
  'CDMP Program': {
    'CDMP': 0,
    'Upcoming Order': 0,
    "Today's Order": 0,
    'Prepare Quotations': 0,
    'Orders on Delivery': 0,
    'Refill Renewals': 0,
    'Link Smart-Actisure Number': 0
  },
  'Delivery': {
    'Delivery Man': 0,
    'Delivery Man on Map': 0,
    'Active Orders': 0,
    'Cash Transfers': 0,
    'Rider Balance': 0
  },
  'Doctors': {
    'Doctors': 0,
    'Specialization': 0
  },
  'Find OTP': {
    'Find Phone': 0,
    'Find Admin Section OTP': 0
  },
  'Logs': {
    'SMS Log': 0,
    'Tutorial Logs': 0
  },
  'M-pesa': {
    'M-Pesa Balance': 0
  },
  'Manufacturer Management': {
    'Registration Request': 0,
    'Associate PPB Request': 0
  },
  'Newsletter': {
    'Push and SMS': 0
  },
  'Pages': {
    'Keys to Pages': 0,
    'Pages': 0
  },
  'Statistics': {
    'Pharmacy Payments': 0,
    'Pharmacy Balances': 0,
    'Doctor Payments': 0,
    'Doctor Balances': 0,
    'Appeal Payment List': 0,
    'Partner Payment List': 0,
    'Withholding Tax Payment List': 0,
    'Hospital Payments': 0,
    'Lab Payments': 0,
    'Imaging Payments': 0,
    'Optical Payments': 0,
    'Medicines': 0,
    'Medicine Rebate': 0
  },
  'Payment Log': {
    'Inbound': 0,
    'Outbound': 0
  },
  'Transactions': {
    'Transactions': 0,
    'List of Insurance Company Transactions': 0,
    'Mpesa Error Transactions': 0,
    'Mpesa Awaiting Transactions': 0
  },
  "I Don't see Medicine Order": {
    'Medicine Orders': 0,
    'Statistics': 0
  },
  'CDMP Reporting': {
    'Expired Programs': 0,
    'To be Expired in 7 Days': 0
  },
  'VDPS': {
    'Members': 0,
    'Requests': 0
  },
  'Subscriptions': {
    'Subscription Plans': 0,
    'Current Subscription Assigned': 0,
    'Subscription Report/Invoice': 0
  },
  'Settings': {
    'Globals': 0,
    'Subscription Setting': 0,
    'Countries': 0,
    'Cities': 0,
    'Languages': 0,
    'Insurance Companies': 0,
    'Currencies': 0,
    'Excel Parsing': 0,
    'Offices': 0,
    'Partners': 0,
    'Application Versions': 0,
    'Manage Skip Provider GeoTag': 0
  },
  'Dental Conditions': {
    'Full Mouth Procedures': 0,
    'Procedure': 0,
    'Time Duration Conditions': 0
  }
};

export const getModuleCount = (label: string): number => {
  return moduleCounts[label] || 0;
};

export const getSubModuleCount = (parentLabel: string, subLabel: string): number => {
  return subModuleCounts[parentLabel]?.[subLabel] || 0;
};


