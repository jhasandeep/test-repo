import {
  Building2,
  FileText,
  XCircle,
  Shield,
  BarChart3,
  FileCheck,
  AlertCircle,
  RefreshCw,
  FileCode,
  Users,
  Upload,
  Pill,
  Heart,
  Receipt,
  PackageSearch,
  ClipboardCheck,
  ShoppingCart,
  Package,
  Truck,
  DollarSign,
  Activity,
  Image,
  Camera,
  UserCog,
  UserCircle,
  Briefcase,
  Stethoscope,
  CreditCard,
  Factory,
  Code,
  BookOpen,
  Mail,
  Key,
  Smartphone,
  Hospital,
  MessageSquare,
  Wallet,
  ArrowRightLeft,
  CheckCircle,
  Clock,
  Target,
  Timer,
  List,
  MapPin,
  TrendingUp,
  Eye,
  Link,
  FlaskConical,
  Scan,
  Headphones,
  Edit,
  Calculator,
  Bell,
  Calendar,
  Settings,
  Globe
} from 'lucide-react';
import { LucideIcon } from 'lucide-react';

// Map submodule labels to icons
export const getSubModuleIcon = (parentModule: string, subModuleLabel: string): LucideIcon => {
  const iconMap: Record<string, LucideIcon> = {
    // Business Hospitals
    'Branches': Building2,
    'Requests': FileText,
    'Declined': XCircle,
    'Hospital Users': Users,
    
    // Insurance
    'E-claims': Shield,
    'Claim Reporting': BarChart3,
    'Offsystem Claims': FileCheck,
    'Claims Required OTP': AlertCircle,
    'Sync Smart Benefits': RefreshCw,
    'Template Claims': FileCode,
    'Member List': Users,
    'Import Members': Upload,
    'Insurance drugs': Pill,
    'Preauth drugs': Pill,
    'Ethical Substitute': Heart,
    'Import benefit': Upload,
    'Import ins drugs': Upload,
    'Prescriptions': Receipt,
    'Prepare Quotations': PackageSearch,
    'Orders on Delivery': Truck,
    'Refill Renewals': RefreshCw,
    'Link Smart-Actisure Number': Link,
    
    // Pre Auth
    'Dental PreAuth': Stethoscope,
    'InPatient PreAuth': Hospital,
    'OutPatient PreAuth': Activity,
    'Counselling PreAuth': MessageSquare,
    'Physiotherapy PreAuth': Activity,
    'Lab PreAuth': FlaskConical,
    'Imaging PreAuth': Scan,
    'Medicine PreAuth': Pill,
    'Optical PreAuth': Eye,
    'PreAuth Reapproval': RefreshCw,
    
    // Orders
    'Total Orders': ShoppingCart,
    'In Process': Clock,
    'Best offer': Target,
    'Prepare Order': PackageSearch,
    'On Delivery': Truck,
    'Not Received': XCircle,
    'In Payment': DollarSign,
    'Takeaway': Package,
    'On Moderation': Eye,
    'Alternative Items': PackageSearch,
    'Best Offer With Alternative Items': Target,
    'Prescription Need To Pay': DollarSign,
    'Prescription In Payment Process': CreditCard,
    'Pre Authorization': Shield,
    'Prescription On Moderation': Eye,
    
    // Transcribing photos
    'Prescription Photos': Camera,
    'Prescription from Ins Panel': Image,
    
    // Users
    'Super Admin': UserCog,
    'Administrators': UserCircle,
    'Customer Care': Headphones,
    'Redactor': Edit,
    'Pharmacy': Pill,
    'Customers': Users,
    'Doctors': Stethoscope,
    'Insurer': Shield,
    'Claim Specialist': FileCheck,
    'Accountant': Calculator,
    'PBM Manager': Briefcase,
    'Brand Manufacturer': Factory,
    'Pharmacist': Pill,
    'Pre Auth Specialist': Shield,
    'Provider Management': Settings,
    'Labs': FlaskConical,
    'Optical Shop': Eye,
    'Imagings': Scan,
    'Provider Engagement': Users,
    'Notification Sender': Bell,
    
    // Manufacturer
    'Drug Request Forms': FileText,
    'Block API to Manufacturer': XCircle,
    'TP Update Requests': RefreshCw,
    
    // Analytics
    'Member History': Clock,
    'Doctor Analytics': TrendingUp,
    'Member Analytics': BarChart3,
    
    // eTIMS
    'Code List': Code,
    'Classification List': List,
    'Notification List': Bell,
    
    // Catalog
    'Categories': List,
    'Subcategories': List,
    'Medicines': Pill,
    'Manage Insurance Formulary': FileText,
    'Manage Regular Formulary': FileText,
    'Personal Items': Package,
    'Drug Index': BookOpen,
    'Banners': Image,
    
    // CDMP Program
    'CDMP': ClipboardCheck,
    'Upcoming Order': Clock,
    "Today's Order": Calendar,
    'Prepare Quotations': PackageSearch,
    'Orders on delivery': Truck,
    'Refill Renewals': RefreshCw,
    'Link Smart-Actisure Number': Link,
    
    // Delivery
    'Delivery Man': Truck,
    'Delivery Man on Map': MapPin,
    'Active Orders': Activity,
    'Cash Transfers': DollarSign,
    'Rider Balance': Wallet,
    
    // Doctors
    'Doctors': Stethoscope,
    'Specialization': List,
    
    // Find OTP
    'Find Phone': Smartphone,
    'Find Admin Section OTP': Key,
    
    // Logs
    'SMS Log': MessageSquare,
    'Tutorial Logs': BookOpen,
    
    // M-pesa
    'M-Pesa Balance': Wallet,
    
    // Manufacturer Management
    'Registration Request': FileText,
    'Associate PPB Request': FileText,
    
    // Newsletter
    'Push and SMS': Mail,
    
    // Pages
    'Keys to Pages': Key,
    'Pages': FileText,
    
    // Statistics
    'Pharmacy Payments': DollarSign,
    'Pharmacy Balances': Wallet,
    'Doctor Payments': DollarSign,
    'Doctor Balances': Wallet,
    'Appeal Payment List': DollarSign,
    'Partner Payment List': DollarSign,
    'Withholding Tax Payment List': DollarSign,
    'Hospital Payments': DollarSign,
    'Lab Payments': DollarSign,
    'Imaging Payments': DollarSign,
    'Optical Payments': DollarSign,
    'Medicines': Pill,
    'Medicine Rebate': DollarSign,
    
    // Payment Log
    'Inbound': ArrowRightLeft,
    'Outbound': ArrowRightLeft,
    
    // Transactions
    'Transactions': CreditCard,
    'List of Insurance Company Transactions': CreditCard,
    'Mpesa Error Transactions': AlertCircle,
    'Mpesa Awaiting Transactions': Clock,
    
    // I Don't see Medicine Order
    'Medicine Orders': ShoppingCart,
    'Statistics': BarChart3,
    
    // CDMP Reporting
    'Expired Programs': XCircle,
    'To be Expired in 7 Days': Clock,
    
    // VDPS
    'Members': Users,
    'Requests': FileText,
    
    // Subscriptions
    'Subscription Plans': FileText,
    'Current Subscription Assigned': CheckCircle,
    'Subscription Report/Invoice': FileText,
    
    // Settings
    'Globals': Settings,
    'Subscription Setting': Settings,
    'Countries': Globe,
    'Cities': MapPin,
    'Languages': Globe,
    'Insurance Companies': Shield,
    'Currencies': DollarSign,
    'Excel Parsing': FileText,
    'Offices': Building2,
    'Partners': Users,
    'Application Versions': Code,
    'Manage Skip Provider GeoTag': MapPin,
    
    // Dental Conditions
    'Full Mouth Procedures': Stethoscope,
    'Procedure': FileText,
    'Time Duration Conditions': Timer
  };
  
  // Try exact match first
  if (iconMap[subModuleLabel]) {
    return iconMap[subModuleLabel];
  }
  
  // Try case-insensitive match
  const lowerLabel = subModuleLabel.toLowerCase();
  for (const [key, icon] of Object.entries(iconMap)) {
    if (key.toLowerCase() === lowerLabel) {
      return icon;
    }
  }
  
  // Default icon
  return FileText;
};

