// This is a helper script to replace ModulePage with GenericModulePage
// Run this manually if needed

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../App.tsx');
let content = fs.readFileSync(filePath, 'utf8');

// Replace pattern: <ModulePage title="Title" icon={Icon} />
// With: <GenericModulePage title="Title" icon={Icon} description="Description" fields={getModuleFields('Title')} />

const moduleTitles = [
  'eTIMS', 'Appointments', 'Appointment Ratings', 'Catalog', 'CDMP Program',
  'Delivery', 'Doctors', 'Find OTP', 'FR Device Management', 'Hospitals',
  'Logs', 'M-pesa', 'Manufacturer Management', 'Provider Domain Management',
  'Newsletter', 'Pages', 'Pickup Orders', 'Pharmacy Branch Management',
  'Pharmacy Device Management', 'Ratings', 'Rebate Payment', 'Schemas',
  'Send SMS', 'Statistics', 'Payment Log', 'Top Selling Drug Management',
  'Transactions', 'User Feedback', "I Don't see Medicine Order",
  'CDMP Reporting', 'VDPS', 'User Edit Log', 'Subscriptions', 'FAQ',
  'Settings', 'Dental Conditions'
];

moduleTitles.forEach(title => {
  const escapedTitle = title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(
    `<ModulePage title="${escapedTitle}" icon=\\{([^}]+)\\} />`,
    'g'
  );
  content = content.replace(
    pattern,
    `<GenericModulePage title="${title}" icon={$1} description="${title} management" fields={getModuleFields('${title}')} />`
  );
});

fs.writeFileSync(filePath, content, 'utf8');
console.log('Replacement complete!');


