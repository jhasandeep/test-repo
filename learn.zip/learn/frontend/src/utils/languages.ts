export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

export const languages: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: 'https://flagcdn.com/w20/gb.png' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: 'https://flagcdn.com/w20/es.png' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: 'https://flagcdn.com/w20/fr.png' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: 'https://flagcdn.com/w20/de.png' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: 'https://flagcdn.com/w20/sa.png' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flag: 'https://flagcdn.com/w20/cn.png' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: 'https://flagcdn.com/w20/jp.png' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: 'https://flagcdn.com/w20/pt.png' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flag: 'https://flagcdn.com/w20/ru.png' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: 'https://flagcdn.com/w20/in.png' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: 'https://flagcdn.com/w20/it.png' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', flag: 'https://flagcdn.com/w20/kr.png' },
];

export const getLanguageByCode = (code: string): Language | undefined => {
  return languages.find(lang => lang.code === code);
};



