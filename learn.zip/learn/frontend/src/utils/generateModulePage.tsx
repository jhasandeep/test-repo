import React from 'react';
import { LucideIcon, Edit, Trash2, Eye } from 'lucide-react';
import ModulePage from '../components/admin/ModulePage';
import DataTable, { Column } from '../components/admin/DataTable';

interface GenerateModulePageProps {
  title: string;
  icon: LucideIcon;
  description: string;
  columns: Column<any>[];
  data: any[];
  searchPlaceholder?: string;
  searchKeys?: string[];
  showActions?: boolean;
}

export const generateModulePage = ({
  title,
  icon,
  description,
  columns,
  data,
  searchPlaceholder,
  searchKeys,
  showActions = true
}: GenerateModulePageProps) => {
  return () => (
    <ModulePage title={title} icon={icon} description={description}>
      <DataTable
        data={data}
        columns={columns}
        searchPlaceholder={searchPlaceholder || `Search ${title.toLowerCase()}...`}
        searchKeys={searchKeys}
        actions={showActions ? (row) => (
          <div className="flex items-center gap-2">
            <button className="p-1 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded transition-colors">
              <Eye size={16} />
            </button>
            <button className="p-1 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded transition-colors">
              <Edit size={16} />
            </button>
            <button className="p-1 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/30 rounded transition-colors">
              <Trash2 size={16} />
            </button>
          </div>
        ) : undefined}
      />
    </ModulePage>
  );
};

// Helper to create sample data
export const createSampleData = (count: number, fields: string[]) => {
  return Array.from({ length: count }, (_, i) => {
    const obj: any = { id: i + 1 };
    fields.forEach(field => {
      if (field.includes('date') || field.includes('Date')) {
        obj[field] = new Date(2025, 0, i + 1).toISOString().split('T')[0];
      } else if (field.includes('status') || field.includes('Status')) {
        obj[field] = ['Active', 'Inactive', 'Pending'][i % 3];
      } else if (field.includes('email') || field.includes('Email')) {
        obj[field] = `user${i + 1}@example.com`;
      } else if (field.includes('phone') || field.includes('Phone')) {
        obj[field] = `+254 712 345 ${String(678 + i).padStart(3, '0')}`;
      } else if (field.includes('amount') || field.includes('Amount') || field.includes('price') || field.includes('Price')) {
        obj[field] = `$${(Math.random() * 1000).toFixed(2)}`;
      } else {
        obj[field] = `${field} ${i + 1}`;
      }
    });
    return obj;
  });
};


