import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';
import AdminLayout from './components/admin/AdminLayout';
import Dashboard from './pages/admin/Dashboard';
import Login from './pages/Login';
import ChangePassword from './pages/admin/ChangePassword';
import BlogAdminManagement from './pages/admin/BlogAdminManagement';
import BusinessHospitalsRoutes from './pages/admin/BusinessHospitals';
import InsuranceRoutes from './pages/admin/Insurance';
import CatalogRoutes from './pages/admin/catalog/CatalogRoutes';
import SettingsRoutes from './pages/admin/settings/SettingsRoutes';
import GenericModulePage from './pages/admin/GenericModulePage';
import { getModuleFields } from './utils/moduleConfig';
import {
  Shield,
  FileText,
  ShoppingCart,
  Image,
  Users,
  CreditCard,
  Factory,
  BarChart3,
  Calendar,
  Star,
  Package,
  ClipboardList,
  Truck,
  Stethoscope,
  Search as SearchIcon,
  Building2
} from 'lucide-react';

function App() {
  return (
    <Router>
      <ThemeProvider>
        <AuthProvider>
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<Login />} />
            
            {/* Protected Admin Routes */}
            <Route
              path="/admin/change-password"
              element={
                <ProtectedRoute>
                  <ChangePassword />
                </ProtectedRoute>
              }
            />
            
            <Route
              path="/admin/blog"
              element={
                <ProtectedRoute>
                  <BlogAdminManagement />
                </ProtectedRoute>
              }
            />
            
            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <Dashboard />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            
            <Route 
              path="/admin/business-hospitals/*" 
              element={
                <ProtectedRoute>
                  <BusinessHospitalsRoutes />
                </ProtectedRoute>
              } 
            />
            
            <Route 
              path="/admin/insurance/*" 
              element={
                <ProtectedRoute>
                  <InsuranceRoutes />
                </ProtectedRoute>
              } 
            />
            
            {/* Jubilee Renewal Policy */}
            <Route
              path="/admin/jubilee-renewal"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <GenericModulePage
                      title="Jubilee Renewal Policy"
                      icon={FileText}
                      description="Manage Jubilee renewal policies"
                      fields={getModuleFields('Jubilee Renewal Policy')}
                    />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            
            {/* Insurance Tracking */}
            <Route
              path="/admin/insurance-tracking"
              element={
                <ProtectedRoute>
                  <AdminLayout>
                    <GenericModulePage
                      title="Insurance Tracking"
                      icon={Shield}
                      description="Track insurance claims and policies"
                      fields={getModuleFields('Insurance Tracking')}
                    />
                  </AdminLayout>
                </ProtectedRoute>
              }
            />
            
            {/* Pre Auth */}
            <Route
              path="/admin/preauth/*"
              element={
                <AdminRoute>
                  <GenericModulePage
                    title="Pre Auth"
                    icon={ClipboardList}
                    description="Pre-authorization requests management"
                    fields={getModuleFields('Pre Auth')}
                  />
                </AdminRoute>
              }
            />
            
            {/* Orders */}
            <Route
              path="/admin/orders/*"
              element={
                <AdminRoute>
                  <GenericModulePage
                    title="Orders"
                    icon={ShoppingCart}
                    description="Manage all orders"
                    fields={getModuleFields('Orders')}
                  />
                </AdminRoute>
              }
            />
            
            {/* Transcribing Photos */}
            <Route
              path="/admin/transcribing/*"
              element={
                <AdminRoute>
                  <GenericModulePage
                    title="Transcribing Photos"
                    icon={Image}
                    description="Manage prescription photo transcriptions"
                    fields={getModuleFields('Transcribing Photos')}
                  />
                </AdminRoute>
              }
            />
            
            {/* Users */}
            <Route
              path="/admin/users/*"
              element={
                <AdminRoute>
                  <GenericModulePage
                    title="Users"
                    icon={Users}
                    description="Manage system users"
                    fields={getModuleFields('Users')}
                  />
                </AdminRoute>
              }
            />
            
            {/* Actisure Payment */}
            <Route
              path="/admin/actisure-payment"
              element={
                <AdminRoute>
                  <GenericModulePage
                    title="Actisure Claim Payment Status"
                    icon={CreditCard}
                    description="Track Actisure claim payment status"
                    fields={getModuleFields('Actisure Claim Payment Status')}
                  />
                </AdminRoute>
              }
            />
            
            {/* Manufacturer */}
            <Route
              path="/admin/manufacturer/*"
              element={
                <AdminRoute>
                  <GenericModulePage
                    title="Manufacturer"
                    icon={Factory}
                    description="Manufacturer management"
                    fields={getModuleFields('Manufacturer')}
                  />
                </AdminRoute>
              }
            />
            
            {/* Analytics */}
            <Route
              path="/admin/analytics/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Analytics" icon={BarChart3} description="Analytics and reporting" fields={getModuleFields('Analytics')} />
                </AdminRoute>
              }
            />
            
            {/* eTIMS */}
            <Route
              path="/admin/etims/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="eTIMS" icon={FileText} description="eTIMS management" fields={getModuleFields('eTIMS')} />
                </AdminRoute>
              }
            />
            
            {/* Appointments */}
            <Route
              path="/admin/appointments"
              element={
                <AdminRoute>
                  <GenericModulePage title="Appointments" icon={Calendar} description="Manage appointments" fields={getModuleFields('Appointments')} />
                </AdminRoute>
              }
            />
            
            {/* Appointment Ratings */}
            <Route
              path="/admin/appointment-ratings"
              element={
                <AdminRoute>
                  <GenericModulePage title="Appointment Ratings" icon={Star} description="Appointment ratings and reviews" fields={getModuleFields('Appointment Ratings')} />
                </AdminRoute>
              }
            />
            
            {/* Catalog */}
            <Route
              path="/admin/catalog/*"
              element={
                <ProtectedRoute>
                  <CatalogRoutes />
                </ProtectedRoute>
              }
            />
            
            {/* CDMP Program */}
            <Route
              path="/admin/cdmp/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="CDMP Program" icon={ClipboardList} description="CDMP program management" fields={getModuleFields('CDMP Program')} />
                </AdminRoute>
              }
            />
            
            {/* Delivery */}
            <Route
              path="/admin/delivery/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Delivery" icon={Truck} description="Delivery management" fields={getModuleFields('Delivery')} />
                </AdminRoute>
              }
            />
            
            {/* Doctors */}
            <Route
              path="/admin/doctors/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Doctors" icon={Stethoscope} description="Doctor management" fields={getModuleFields('Doctors')} />
                </AdminRoute>
              }
            />
            
            {/* Find OTP */}
            <Route
              path="/admin/find-otp/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Find OTP" icon={SearchIcon} description="OTP lookup and management" fields={getModuleFields('Find OTP')} />
                </AdminRoute>
              }
            />
            
            {/* FR Device Management */}
            <Route
              path="/admin/fr-device"
              element={
                <AdminRoute>
                  <GenericModulePage title="FR Device Management" icon={FileText} description="FR device management" fields={getModuleFields('FR Device Management')} />
                </AdminRoute>
              }
            />
            
            {/* Hospitals */}
            <Route
              path="/admin/hospitals"
              element={
                <AdminRoute>
                  <GenericModulePage title="Hospitals" icon={Building2} description="Hospital management" fields={getModuleFields('Hospitals')} />
                </AdminRoute>
              }
            />
            
            {/* Logs */}
            <Route
              path="/admin/logs/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Logs" icon={FileText} description="System logs" fields={getModuleFields('Logs')} />
                </AdminRoute>
              }
            />
            
            {/* M-pesa */}
            <Route
              path="/admin/mpesa/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="M-pesa" icon={CreditCard} description="M-Pesa transactions" fields={getModuleFields('M-pesa')} />
                </AdminRoute>
              }
            />
            
            {/* Manufacturer Management */}
            <Route
              path="/admin/manufacturer-management/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Manufacturer Management" icon={Factory} description="Manufacturer registration and management" fields={getModuleFields('Manufacturer Management')} />
                </AdminRoute>
              }
            />
            
            {/* Provider Domain Management */}
            <Route
              path="/admin/provider-domain"
              element={
                <AdminRoute>
                  <GenericModulePage title="Provider Domain Management" icon={Building2} description="Provider domain configuration" fields={getModuleFields('Provider Domain Management')} />
                </AdminRoute>
              }
            />
            
            {/* Newsletter */}
            <Route
              path="/admin/newsletter/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Newsletter" icon={FileText} description="Newsletter management" fields={getModuleFields('Newsletter')} />
                </AdminRoute>
              }
            />
            
            {/* Pages */}
            <Route
              path="/admin/pages/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Pages" icon={FileText} description="Page management" fields={getModuleFields('Pages')} />
                </AdminRoute>
              }
            />
            
            {/* Pickup Orders */}
            <Route
              path="/admin/pickup-orders"
              element={
                <AdminRoute>
                  <GenericModulePage title="Pickup Orders" icon={ShoppingCart} description="Pickup order management" fields={getModuleFields('Pickup Orders')} />
                </AdminRoute>
              }
            />
            
            {/* Pharmacy Branch Management */}
            <Route
              path="/admin/pharmacy-branch"
              element={
                <AdminRoute>
                  <GenericModulePage title="Pharmacy Branch Management" icon={Building2} description="Pharmacy branch management" fields={getModuleFields('Pharmacy Branch Management')} />
                </AdminRoute>
              }
            />
            
            {/* Pharmacy Device Management */}
            <Route
              path="/admin/pharmacy-device"
              element={
                <AdminRoute>
                  <GenericModulePage title="Pharmacy Device Management" icon={FileText} description="Pharmacy device management" fields={getModuleFields('Pharmacy Device Management')} />
                </AdminRoute>
              }
            />
            
            {/* Ratings */}
            <Route
              path="/admin/ratings"
              element={
                <AdminRoute>
                  <GenericModulePage title="Ratings" icon={Star} description="User ratings and reviews" fields={getModuleFields('Ratings')} />
                </AdminRoute>
              }
            />
            
            {/* Rebate Payment */}
            <Route
              path="/admin/rebate-payment"
              element={
                <AdminRoute>
                  <GenericModulePage title="Rebate Payment" icon={CreditCard} description="Rebate payment management" fields={getModuleFields('Rebate Payment')} />
                </AdminRoute>
              }
            />
            
            {/* Schemas */}
            <Route
              path="/admin/schemas"
              element={
                <AdminRoute>
                  <GenericModulePage title="Schemas" icon={FileText} description="Database schema management" fields={getModuleFields('Schemas')} />
                </AdminRoute>
              }
            />
            
            {/* Send SMS */}
            <Route
              path="/admin/send-sms"
              element={
                <AdminRoute>
                  <GenericModulePage title="Send SMS" icon={FileText} description="SMS sending management" fields={getModuleFields('Send SMS')} />
                </AdminRoute>
              }
            />
            
            {/* Statistics */}
            <Route
              path="/admin/statistics/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Statistics" icon={BarChart3} description="Statistics and reports" fields={getModuleFields('Statistics')} />
                </AdminRoute>
              }
            />
            
            {/* Payment Log */}
            <Route
              path="/admin/payment-log/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Payment Log" icon={FileText} description="Payment transaction logs" fields={getModuleFields('Payment Log')} />
                </AdminRoute>
              }
            />
            
            {/* Top Selling Drug Management */}
            <Route
              path="/admin/top-selling-drugs"
              element={
                <AdminRoute>
                  <GenericModulePage title="Top Selling Drug Management" icon={Package} description="Top selling drugs management" fields={getModuleFields('Top Selling Drug Management')} />
                </AdminRoute>
              }
            />
            
            {/* Transactions */}
            <Route
              path="/admin/transactions/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Transactions" icon={CreditCard} description="Transaction management" fields={getModuleFields('Transactions')} />
                </AdminRoute>
              }
            />
            
            {/* User Feedback */}
            <Route
              path="/admin/user-feedback"
              element={
                <AdminRoute>
                  <GenericModulePage title="User Feedback" icon={Star} description="User feedback and suggestions" fields={getModuleFields('User Feedback')} />
                </AdminRoute>
              }
            />
            
            {/* Medicine Orders */}
            <Route
              path="/admin/medicine-orders/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="I Don't see Medicine Order" icon={Package} description="Medicine orders not visible in main list" fields={getModuleFields("I Don't see Medicine Order")} />
                </AdminRoute>
              }
            />
            
            {/* CDMP Reporting */}
            <Route
              path="/admin/cdmp-reporting/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="CDMP Reporting" icon={FileText} description="CDMP program reporting" fields={getModuleFields('CDMP Reporting')} />
                </AdminRoute>
              }
            />
            
            {/* VDPS */}
            <Route
              path="/admin/vdps/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="VDPS" icon={Users} description="VDPS management" fields={getModuleFields('VDPS')} />
                </AdminRoute>
              }
            />
            
            {/* User Edit Log */}
            <Route
              path="/admin/user-edit-log"
              element={
                <AdminRoute>
                  <GenericModulePage title="User Edit Log" icon={FileText} description="User edit history log" fields={getModuleFields('User Edit Log')} />
                </AdminRoute>
              }
            />
            
            {/* Subscriptions */}
            <Route
              path="/admin/subscriptions/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Subscriptions" icon={FileText} description="Subscription management" fields={getModuleFields('Subscriptions')} />
                </AdminRoute>
              }
            />
            
            {/* FAQ */}
            <Route
              path="/admin/faq"
              element={
                <AdminRoute>
                  <GenericModulePage title="FAQ" icon={FileText} description="Frequently asked questions" fields={getModuleFields('FAQ')} />
                </AdminRoute>
              }
            />
            
            {/* Settings */}
            <Route 
              path="/admin/settings/*" 
              element={
                <ProtectedRoute>
                  <SettingsRoutes />
                </ProtectedRoute>
              } 
            />
            
            {/* Dental Conditions */}
            <Route
              path="/admin/dental-conditions/*"
              element={
                <AdminRoute>
                  <GenericModulePage title="Dental Conditions" icon={Stethoscope} description="Dental conditions management" fields={getModuleFields('Dental Conditions')} />
                </AdminRoute>
              }
            />
            
            {/* Default redirect */}
            <Route path="/" element={<Navigate to="/admin" replace />} />
          </Routes>
        </AuthProvider>
      </ThemeProvider>
    </Router>
  );
}

export default App;