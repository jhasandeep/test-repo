# Frontend - Livia Admin Panel

A modern React + TypeScript frontend for the Livia Hospital Management Admin Panel, integrated with the NestJS backend.

## Features

- 🎨 Modern, responsive UI matching the shoe website design
- 👥 User management system integrated with backend
- 🛍️ Product showcase section
- 🎯 Built with React 18 + TypeScript
- ⚡ Powered by Vite for fast development

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

```bash
cd frontend
npm install
```

### Development

```bash
npm run dev
```

The frontend will be available at `http://localhost:3000`

### Build

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```

## Project Structure

```
frontend/
├── src/
│   ├── components/
│   │   ├── Navigation.tsx       # Navigation bar
│   │   ├── Hero.tsx             # Hero section
│   │   ├── ProductsSection.tsx  # Products display
│   │   ├── UserManagement.tsx   # User CRUD interface
│   │   └── Footer.tsx           # Footer component
│   ├── services/
│   │   └── api.ts               # API service for backend integration
│   ├── App.tsx                  # Main app component
│   ├── main.tsx                 # Entry point
│   └── index.css                # Global styles
├── package.json
├── vite.config.ts
└── tsconfig.json
```

## Backend Integration

The frontend connects to the NestJS backend running on `http://localhost:5000`.

API endpoints:
- `GET /users` - Get all users
- `GET /users/:id` - Get user by ID
- `POST /users/create` - Create user
- `PATCH /users/update/:id` - Update user
- `DELETE /users/delete/:id` - Delete user

Make sure the backend is running before using the user management features!



