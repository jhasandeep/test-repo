# Stride Premium Footwear - Full Stack Application

A modern full-stack application with a React + TypeScript frontend and NestJS backend.

## Project Structure

```
.
├── backend/          # NestJS backend API
├── frontend/         # React + TypeScript frontend
└── reference-ui/     # Reference UI template (shoe website design)
```

## Quick Start

### Backend Setup

```bash
cd backend
npm install
npm run start:dev
```

The backend API will be available at `http://localhost:5000`

**Important:** Make sure MySQL is running and configured in `backend/src/app.module.ts`

### Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

The frontend will be available at `http://localhost:3000`

## Features

### Frontend
- 🎨 Modern, responsive shoe website UI (Stride Premium Footwear)
- 👥 User management system integrated with backend
- 🛍️ Product showcase section
- 📱 Mobile-responsive design
- ⚡ Built with React 18 + TypeScript + Vite

### Backend
- 🔌 RESTful API with NestJS
- 🗄️ MySQL database integration with TypeORM
- 👤 User CRUD operations
- ✅ Input validation with class-validator
- 🔓 CORS enabled for frontend integration

## Tech Stack

### Frontend
- React 18
- TypeScript
- Vite
- Axios
- CSS3

### Backend
- NestJS
- TypeScript
- TypeORM
- MySQL
- class-validator

## API Endpoints

- `GET /users` - Get all users
- `GET /users/:id` - Get user by ID
- `POST /users/create` - Create a new user
- `PATCH /users/update/:id` - Update a user
- `DELETE /users/delete/:id` - Delete a user

## User Management

Click the "Users" button in the navigation to access the user management interface where you can:
- Create new users
- View all users
- Edit existing users
- Delete users

## Reference UI

The `reference-ui/` folder contains the original HTML/CSS template that was used as a reference for creating the React frontend.