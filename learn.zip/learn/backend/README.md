# Backend - NestJS API

NestJS backend API for user management with MySQL database.

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- MySQL database
- npm or yarn

### Installation

```bash
cd backend
npm install
```

### Database Configuration

Update the database configuration in `src/app.module.ts`:

```typescript
{
  type: 'mysql',
  host: 'localhost',
  port: 3306,
  username: 'root',
  password: 'your_password',
  database: 'db',
  entities: [join(process.cwd(), 'dist/**/*.entity.js')],
  synchronize: true,
}
```

### Running the Application

```bash
# Development mode (with watch)
npm run start:dev

# Production mode
npm run start:prod

# Build
npm run build
```

The API will be available at `http://localhost:5000`

## API Endpoints

### Users

- `GET /users` - Get all users
- `GET /users/:id` - Get user by ID
- `POST /users/create` - Create a new user
- `PATCH /users/update/:id` - Update a user
- `DELETE /users/delete/:id` - Delete a user

### User Schema

```typescript
{
  id: number;
  name: string;
  email: string;
  data: string[];
}
```

## CORS

CORS is enabled to allow requests from the React frontend running on `http://localhost:3000`.



