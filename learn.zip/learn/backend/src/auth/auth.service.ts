import { Injectable, UnauthorizedException, BadRequestException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
  ) {}

  // Store OTPs temporarily (in production, use Redis or database)
  private otpStore: Map<string, { otp: string; expiresAt: number }> = new Map();

  async register(registerDto: RegisterDto) {
    const existingUser = await this.usersService.findByEmail(registerDto.email);
    if (existingUser) {
      throw new BadRequestException('User with this email already exists');
    }

    const hashedPassword = await bcrypt.hash(registerDto.password, 10);
    const user = await this.usersService.create({
      name: registerDto.name,
      email: registerDto.email,
      password: hashedPassword,
      data: [],
    });

    const payload = { email: user.email, sub: user.id };
    return {
      access_token: this.jwtService.sign(payload),
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
      },
    };
  }

  async login(loginDto: LoginDto) {
    const user = await this.usersService.findByEmail(loginDto.email);
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    // Check if password matches
    const isPasswordValid = await bcrypt.compare(loginDto.password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    // If OTP is provided, verify it
    if (loginDto.otp) {
      const storedOtp = this.otpStore.get(loginDto.email);
      if (!storedOtp || storedOtp.otp !== loginDto.otp) {
        throw new UnauthorizedException('Invalid OTP');
      }
      if (Date.now() > storedOtp.expiresAt) {
        this.otpStore.delete(loginDto.email);
        throw new UnauthorizedException('OTP expired');
      }
      this.otpStore.delete(loginDto.email);
    } else {
      // Generate and send OTP (for test, use 1111)
      const otp = '1111'; // In production, generate random OTP
      this.otpStore.set(loginDto.email, {
        otp,
        expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes
      });
      return {
        requiresOtp: true,
        message: 'OTP sent to your email/phone. Please enter it below (test OTP: 1111).',
      };
    }

    const payload = { email: user.email, sub: user.id };
    return {
      access_token: this.jwtService.sign(payload),
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
      },
    };
  }

  async validateUser(email: string, password: string): Promise<any> {
    const user = await this.usersService.findByEmail(email);
    if (user && (await bcrypt.compare(password, user.password))) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }
}



