import { IsArray, IsEmail, IsNotEmpty, IsString, IsOptional } from "class-validator";

export class CreateUserDto {
    @IsString()
    @IsNotEmpty()
    name: string;

    @IsEmail({}, { message: 'Invalid email format' })
    @IsNotEmpty({ message: 'Email is required' })
    email: string;

    @IsString()
    @IsOptional()
    password?: string;

    @IsArray()
    @IsOptional()
    data?: string[];
}
